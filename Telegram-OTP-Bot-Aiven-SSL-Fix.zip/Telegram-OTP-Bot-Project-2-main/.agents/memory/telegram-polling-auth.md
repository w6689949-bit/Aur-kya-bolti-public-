---
name: Telegram polling authorization failures
description: Permanent bot-token 401 errors need a terminal stop to avoid rapid retries.
---

Treat Telegram 401 responses as permanent until `TELEGRAM_BOT_TOKEN` is corrected. With a zero-interval polling loop, leaving authorization failures unhandled causes rapid repeated requests. Attach the failure handler before startup awaits and stop polling with cancellation; restart the service after the token is updated.

**Why:** An invalid token produced repeated unauthorized polling requests until the workflow was stopped.

**How to apply:** When starting a Telegram bot with long polling, stop the poller on 401 and make the required secret update explicit. Do not retry the same rejected token continuously.