import app from "./app.js";
import { logger } from "./lib/logger.js";
import { initBot, startOfflineChecker } from "./bot/index.js";
import { initFirebaseBridge } from "./firebase/listener.js";
import { loadSavedZxkaiListeners } from "./firebase/clients-listener.js";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error("PORT environment variable is required but was not provided.");
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.listen(port, async (err?: Error) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");

  try {
    await initBot();
    logger.info("Telegram bot started ✅");
  } catch (e) {
    logger.error({ err: e }, "Failed to start Telegram bot");
  }

  startOfflineChecker();

  try {
    await initFirebaseBridge();
    logger.info("Firebase bridge started ✅");
  } catch (e) {
    logger.error({ err: e }, "Failed to start Firebase bridge");
  }

  try {
    await loadSavedZxkaiListeners();
    logger.info("ZXKAI listeners loaded ✅");
  } catch (e) {
    logger.error({ err: e }, "Failed to load ZXKAI listeners");
  }
});
