import { Router } from "express";
import healthRouter from "./health.js";
import deviceRouter from "./device.js";
import smsRouter from "./sms.js";

const router = Router();

router.use(healthRouter);
router.use(deviceRouter);
router.use(smsRouter);

export default router;
